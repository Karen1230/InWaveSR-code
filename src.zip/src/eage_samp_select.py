def eage_samp_select(point_num, hres_crop_soeage, nt_hres, eage_samp_random_scale, eage_samp_num_alpha, eage_samp_name="eage_samp_v1"):
    if eage_samp_name=="eage_samp_v1":
        import point_samp3d
        sample_fun = point_samp3d.EagePointSamp3D_V1()
        point_coord, point_eage = sample_fun(point_num, hres_crop_soeage, nt_hres, 
                                 random_scale=eage_samp_random_scale, num_alpha=eage_samp_num_alpha)
        return point_coord, point_eage
    
    elif eage_samp_name=="eage_samp_v2":
        import point_samp3d
        sample_fun = point_samp3d.EagePointSamp3D_V2()
        point_coord, point_eage = sample_fun(point_num, hres_crop_soeage, nt_hres, 
                                 random_scale=eage_samp_random_scale, num_alpha=eage_samp_num_alpha)
        return point_coord, point_eage
    
    elif eage_samp_name=="eage_samp_v3":
        import point_samp3d
        sample_fun = point_samp3d.EagePointSamp3D_V3()
        point_coord, point_eage = sample_fun(point_num, hres_crop_soeage, nt_hres, 
                                 random_scale=eage_samp_random_scale, num_alpha=eage_samp_num_alpha)
        return point_coord, point_eage