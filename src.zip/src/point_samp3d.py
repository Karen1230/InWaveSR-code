from abc import ABC, abstractmethod
import sys
import os
import numpy as np
import matplotlib
import matplotlib.pyplot as plt

import grid_process

import data_flie_transform as dft
import npdata_visualize as nvl

class DrawHeatImage(nvl.DrawFun):
    def __init__(self, cmap="RdBu", interpolation=None, colorbar_orientation=None, colorbar_aspect=20, aspect=1):
        self.cmap = cmap
        self.interpolation = interpolation # spline16
        self.colorbar_orientation = colorbar_orientation # vertical and horizontal
        self.colorbar_aspect = colorbar_aspect
        self.aspect = aspect

    def __call__(self, fig, ax, frame, vmin, vmax):
        im = ax.imshow(frame, vmin=vmin, vmax=vmax, cmap=self.cmap, interpolation=self.interpolation, aspect=self.aspect)

        # if self.colorbar_orientation:
        #     cbar = fig.colorbar(im, orientation=self.colorbar_orientation, aspect=self.colorbar_aspect)

        return im

class DrawPointImageWithBg(nvl.DrawHeatImage):
    def __init__(self, point_color="black", cmap="RdBu", interpolation=None, colorbar_orientation=None, colorbar_aspect=20, aspect=1):
        self.point_color = point_color
        super().__init__(
            cmap=cmap, 
            interpolation=interpolation, 
            colorbar_orientation=colorbar_orientation, 
            colorbar_aspect=colorbar_aspect, 
            aspect=aspect
        )

    def __call__(self, fig, ax, frame, vmin, vmax):
        point_frame, bg_frame = frame
        point_x, point_y = point_frame
        im = super().__call__(fig, ax, bg_frame, vmin, vmax)
        ax.scatter(point_x, point_y, c=self.point_color)
        return im
    
class DrawDuPointImageWithBg(DrawHeatImage):
    def __init__(self, point_colors=["orange", "green"], cmap="RdBu", interpolation=None, colorbar_orientation=None, colorbar_aspect=20, aspect=1):
        self.point_colors = point_colors
        super().__init__(
            cmap=cmap, 
            interpolation=interpolation, 
            colorbar_orientation=colorbar_orientation, 
            colorbar_aspect=colorbar_aspect, 
            aspect=aspect
        )

    def __call__(self, fig, ax, frame, vmin, vmax):
        point_frame, flag_frame, bg_frame = frame
        point_x, point_y = point_frame
        im = super().__call__(fig, ax, bg_frame, vmin, vmax)
        for i in range(len(flag_frame)):
            ax.scatter(point_x[i], point_y[i], c=self.point_colors[flag_frame[i]])
        return im
 

class SingleImageGeneratorUnlimit(nvl.SingleImageGenerator):
    def __init__(self, figsize, fontsize, draw_fun, tick_info=nvl.TickInfo()):
        super().__init__(figsize, fontsize, draw_fun, tick_info)

    def __call__(self, npdata_list, frame_folder, frame_name, title=None, vmin=None, vmax=None):
        npdata = npdata_list
        plt.rcParams.update({'font.size': self.fontsize})
        os.makedirs(frame_folder, exist_ok=True)
        fig, ax = plt.subplots(nrows=1, ncols=1, figsize=self.figsize)
        self.draw_fun(fig, ax, npdata, vmin, vmax)
        plt.title(title, fontsize=self.fontsize)
        self.tick_info.apply(ax, self.fontsize)
        fig.savefig(os.path.join(frame_folder, frame_name))
        plt.cla()
        matplotlib.pyplot.close()

class SingleImageGeneratorUnlimit(nvl.SingleImageGenerator):
    def __init__(self, figsize, fontsize, draw_fun, tick_info=nvl.TickInfo()):
        super().__init__(figsize, fontsize, draw_fun, tick_info)

    def __call__(self, npdata_list, frame_folder, frame_name, title=None, vmin=None, vmax=None):
        npdata = npdata_list
        plt.rcParams.update({"font.size": self.fontsize})
        os.makedirs(frame_folder, exist_ok=True)
        fig, ax = plt.subplots(nrows=1, ncols=1, figsize=self.figsize)

        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.spines["bottom"].set_visible(False)
        ax.spines["left"].set_visible(False)
        ax.axis("off")

        self.draw_fun(fig, ax, npdata, vmin, vmax)
        # plt.title(title, fontsize=self.fontsize)
        # self.tick_info.apply(ax, self.fontsize)
        fig.savefig(os.path.join(frame_folder, frame_name), bbox_inches='tight', pad_inches=0, transparent=True)
        plt.cla()
        matplotlib.pyplot.close()

class PointSamp3D(ABC):
    @abstractmethod
    def __call__(self):
        pass

class RandomPointSamp3D(PointSamp3D):
    def __call__(self, point_num, grid_shape):
        point_coord = np.random.rand(point_num, 3) * (grid_shape - 1)
        return point_coord

def PointElimArea(slice_random_adjust_coords, nz, nx):
    mask1 = slice_random_adjust_coords[:,0] > 0.0
    mask2 = slice_random_adjust_coords[:,1] > 0.0
    mask3 = slice_random_adjust_coords[:,0] < nz - 1
    mask4 = slice_random_adjust_coords[:,1] < nx - 1

    mask = mask1 & mask2 & mask3 & mask4
    slice_random_adjust_range_coords = slice_random_adjust_coords[mask]

    return slice_random_adjust_range_coords

def PointSup(slice_random_adjust_range_coords, nt, nz, nx, point_num):
    random_point_num = len(slice_random_adjust_range_coords)
    slice_random_adjust_range_coords_tzx = np.concatenate(
        [np.random.rand(random_point_num, 1) * (nt - 1), slice_random_adjust_range_coords], axis=1)
    eage_coord_num = len(slice_random_adjust_range_coords_tzx)
    
    random_no_eage_point_num = point_num - eage_coord_num
    sample_fun = RandomPointSamp3D()
    random_no_eage_coords = sample_fun(random_no_eage_point_num, np.array((nt, nz, nx)))
    point_coord = np.concatenate([slice_random_adjust_range_coords_tzx, random_no_eage_coords], axis=0)

    point_eage = np.concatenate([
        np.ones(random_point_num), np.zeros(random_no_eage_point_num)
    ], axis=0)

    return point_coord, point_eage

def PointLimitNum(random_eage_coords, point_num):
    eage_coord_num = random_eage_coords.shape[0]
    if eage_coord_num > point_num:
        slice_random_coords = random_eage_coords[:int(point_num)]
    else:
        slice_random_coords = random_eage_coords[:]

    return slice_random_coords

def PointShuffle(point_coord, point_eage):
    point_num = len(point_coord)
    point_coord_eith_eage = np.concatenate(
        [point_coord, point_eage.reshape([point_num, 1])], axis=-1
    )
    np.random.shuffle(point_coord_eith_eage)
    point_coord = point_coord_eith_eage[:, :3]
    point_eage = point_coord_eith_eage[:, 3]
    return point_coord, point_eage

class EagePointSamp3D_V1(PointSamp3D):
    # num_alpha: 0.0 - 1.0
    def __call__(self, point_num, npdata_eage, nt, random_scale=7.0, num_alpha=0.5):
        nz, nx = npdata_eage.shape
        eage_coords = np.argwhere(npdata_eage==1)
        eage_coord_num = eage_coords.shape[0]
        random_eage_coords = eage_coords[np.random.permutation(eage_coord_num)]
        # random_eage_coords = np.concatenate([eage_coords]*int(point_num//256), axis=0)
        # eage_coord_num = random_eage_coords.shape[0]

        # if eage_coord_num > point_num * num_alpha:
        #     slice_random_coords = random_eage_coords[:int(point_num * num_alpha)]
        # else:
        #     slice_random_coords = random_eage_coords[:]

        slice_random_coords = PointLimitNum(random_eage_coords, int(point_num * num_alpha))

        random_adjust_value = np.random.normal(loc=0.0, scale=random_scale, size=slice_random_coords.shape)
        slice_random_adjust_coords = slice_random_coords + random_adjust_value

        # mask1 = slice_random_adjust_coords[:,0] > 0.0
        # mask2 = slice_random_adjust_coords[:,1] > 0.0
        # mask3 = slice_random_adjust_coords[:,0] < nz - 1
        # mask4 = slice_random_adjust_coords[:,1] < nx - 1

        # mask = mask1 & mask2 & mask3 & mask4
        # slice_random_adjust_range_coords = slice_random_adjust_coords[mask]

        slice_random_adjust_range_coords = PointElimArea(slice_random_adjust_coords, nz, nx)

        eage_point_num = len(slice_random_adjust_range_coords)

        # random_point_num = len(slice_random_adjust_range_coords)
        # slice_random_adjust_range_coords_tzx = np.concatenate(
        #     [np.random.rand(random_point_num, 1) * (nt - 1), slice_random_adjust_range_coords], axis=1)
        # eage_coord_num = len(slice_random_adjust_range_coords_tzx)
        
        # random_no_eage_point_num = point_num - eage_coord_num
        # sample_fun = RandomPointSamp3D()
        # random_no_eage_coords = sample_fun(random_no_eage_point_num, np.array((nt, nz, nx)))
        # point_coord = np.concatenate([slice_random_adjust_range_coords_tzx, random_no_eage_coords], axis=0)

        point_coord, point_eage = PointSup(slice_random_adjust_range_coords, nt, nz, nx, point_num)

        point_coord, point_eage = PointShuffle(point_coord, point_eage)

        return point_coord, point_eage

class EagePointSamp3D_V2(PointSamp3D):
    # num_alpha: 0.0 - 1.0
    def __call__(self, point_num, npdata_eage, nt, random_scale=7.0, num_alpha=0.5):
        nz, nx = npdata_eage.shape
        eage_coords = np.argwhere(npdata_eage==1)
        eage_coord_num = eage_coords.shape[0]
        random_eage_coords = eage_coords[np.random.permutation(eage_coord_num)]
        slice_random_coords = random_eage_coords
        # slice_random_coords = PointLimitNum(random_eage_coords, int(point_num * num_alpha))

        random_adjust_value = np.random.normal(loc=0.0, scale=random_scale, size=slice_random_coords.shape)
        slice_random_adjust_coords = slice_random_coords + random_adjust_value

        slice_random_adjust_coords = PointLimitNum(slice_random_adjust_coords, int(point_num * num_alpha))

        slice_random_adjust_range_coords = PointElimArea(slice_random_adjust_coords, nz, nx)


        point_coord, point_eage = PointSup(slice_random_adjust_range_coords, nt, nz, nx, point_num)

        point_coord, point_eage = PointShuffle(point_coord, point_eage)

        return point_coord, point_eage
    
class EagePointSamp3D_V3(PointSamp3D):
    # num_alpha: 0.0 - 1.0
    def __call__(self, point_num, npdata_eage, nt, random_scale=7.0, num_alpha=0.5):
        nz, nx = npdata_eage.shape
        grid_process_fun = grid_process.SoEageExpand()
        expand_npdata_eage = grid_process_fun(npdata_eage, expand_alpha=2)
        eage_coords = np.argwhere(expand_npdata_eage==1)
        eage_coord_num = eage_coords.shape[0]
        random_eage_coords = eage_coords[np.random.permutation(eage_coord_num)]
        slice_random_coords = random_eage_coords
        # slice_random_coords = PointLimitNum(random_eage_coords, int(point_num * num_alpha))

        random_adjust_value = np.random.normal(loc=0.0, scale=random_scale, size=slice_random_coords.shape)
        slice_random_adjust_coords = slice_random_coords + random_adjust_value

        slice_random_adjust_coords = PointLimitNum(slice_random_adjust_coords, int(point_num * num_alpha))

        slice_random_adjust_range_coords = PointElimArea(slice_random_adjust_coords, nz, nx)


        point_coord, point_eage = PointSup(slice_random_adjust_range_coords, nt, nz, nx, point_num)

        point_coord, point_eage = PointShuffle(point_coord, point_eage)

        return point_coord, point_eage

def main():
    
    image_folder = os.path.join("src", "point_samp3d_test_image")
    data_file_folder = "data"
    data_file_name = "eval.npz"
    dtype = "float32"
    sod_name = "sbd"
    figsize = (24, 10)
    fontsize = 20
    nt = 128
    point_num = 1024
    scale = 10.0
    os.makedirs(image_folder, exist_ok=True)
    random_coords_name = "random_coords"
    eage_coords_name = "eage_coords"
    eage_alpha = 0.4

    npdata_dict = np.load(os.path.join(data_file_folder, data_file_name))
    npdata_sod = npdata_dict[sod_name].astype(dtype)

    grid_process_fun = grid_process.SodToSoEage()
    npdata_soeage = grid_process_fun(npdata_sod)

    draw_fun = DrawPointImageWithBg(point_color="blue")
    image_generator = SingleImageGeneratorUnlimit(figsize, fontsize, draw_fun)

    sample_fun = RandomPointSamp3D()
    random_coords = sample_fun(point_num, np.array((nt, *npdata_soeage.shape)))
    npdata_list = [[random_coords[:, 2], random_coords[:, 1]], npdata_soeage]
    image_generator(npdata_list, image_folder, random_coords_name, random_coords_name)

    sample_fun = EagePointSamp3D_V1()
    eage_coords = sample_fun(point_num, npdata_soeage, nt=nt, scale=scale, alpha=eage_alpha)
    npdata_list = [[eage_coords[:, 2], eage_coords[:, 1]], npdata_soeage]
    image_generator(npdata_list, image_folder, eage_coords_name, eage_coords_name)


if __name__ == "__main__":
    main()
