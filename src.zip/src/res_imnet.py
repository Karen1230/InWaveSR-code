import torch
import torch.nn as nn

class SimpFeaSelfAtt(nn.Module):
    def __init__(self, fea_num):
        super(SimpFeaSelfAtt, self).__init__()

        self.linear = nn.Linear(fea_num, fea_num)
        self.softmax = nn.Softmax(dim=-1)

    def forward(self, x):
        shape = x.shape
        x = x.reshape(-1, shape[-1])
        query = self.linear(x)
        attention = self.softmax(query)

        out = attention * x
        out = out.reshape(*shape)
        return out

class AttResBlock(nn.Module):
    def __init__(self, in_features, out_features, final_relu=True):
        super(AttResBlock, self).__init__()
        self.fc = nn.Linear(in_features, out_features)
        self.softplus = nn.Softplus()
        self.att = SimpFeaSelfAtt(out_features)
        self.relu = nn.LeakyReLU()
        self.final_relu = final_relu

    def forward(self, x):
        x = self.fc(x)
        x = self.softplus(x)
        identity = x
        x = self.att(x)
        x += identity
        if self.final_relu:
            x = self.relu(x)

        return x



class ImNet(nn.Module):
    def __init__(self, dim, in_features, out_features, n_base_feature=32):
        super(ImNet, self).__init__()

        in_features_with_dim = dim + in_features

        self.layer1 = AttResBlock(in_features_with_dim, n_base_feature * 16)

        self.layer2 = AttResBlock(n_base_feature * 16 + in_features_with_dim, n_base_feature * 8)

        self.layer3 = AttResBlock(n_base_feature * 8  + in_features_with_dim, n_base_feature * 4)

        self.layer4 = AttResBlock(n_base_feature * 4  + in_features_with_dim, n_base_feature * 2)

        self.layer5 = AttResBlock(n_base_feature * 2 + in_features_with_dim, n_base_feature)

        self.layer6 = nn.Linear(n_base_feature * 1, out_features)

    def forward(self, x):
        x0 = x # 35

        x1 = self.layer1(x0) # 32 * 16
        x1 = torch.cat([x1, x0], dim=-1) # 32 * 16 + 35

        x2 = self.layer2(x1) # 32 *8
        x2 = torch.cat([x2, x0], dim=-1) # 32 * 8 + 35

        x3 = self.layer3(x2) # 32 * 4
        x3 = torch.cat([x3, x0], dim=-1) # 32 * 4 + 35

        x4 = self.layer4(x3) # 32 * 2
        x4 = torch.cat([x4, x0], dim=-1) # 32 * 2 + 35

        x5 = self.layer5(x4) # 32 * 1

        x6 = self.layer6(x5) # 4

        return x6

def main():
    imnet = ImNet(dim=3, in_features=32, out_features=4, n_base_feature=32)
    input = torch.rand(20, 35)
    output = imnet(input)
    model_param_count = lambda model: sum(x.numel() for x in model.parameters())
    unet_param_count = model_param_count(imnet)
    print(f"input's shape: {input.detach().numpy().shape}")
    print(f"output's shape: {output.detach().numpy().shape}")
    print(f"model's num: {unet_param_count}")

if __name__ == "__main__":
    main()