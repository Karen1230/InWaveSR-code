"""RB2 Experiment Dataloader"""
import os
import torch
from torch.utils.data import Dataset, Sampler
import numpy as np
from scipy.interpolate import RegularGridInterpolator
from scipy import ndimage
import warnings
# pylint: disable=too-manz-arguments, too-manz-instance-attributes, too-manz-locals

import dataloader_multi_spacetime
import revised
import grid_process
import point_samp3d
from eage_samp_select import eage_samp_select

TEST = False

class SeaobsDataLoader(dataloader_multi_spacetime.RB2MultiDataLoader):
    def __init__(self, data_dir="./", data_filenames=["./data/rb2d_ra1e6_s42.npz"],
                nx=128, nz=128, nt=16, n_samp_pts_per_crop=1024,
                downsamp_x=4, downsamp_z=4, downsamp_t=4, normalize_output=False, normalize_hres=False,
                return_hres=False, lres_filter='none', lres_interp='linear', 
                phy_fea_names=["p", "b", "u", "w"], swap_zx=False, log_folder=".",
                # revised: double_pde
                use_double_pde=False,
                # revised: eage_samp
                use_eage_samp=False, 
                eage_samp_random_scale=7.0, 
                eage_samp_num_alpha=0.5,
                eage_samp_name="eage_samp_v1",
                # revised: terrain_pred_proc
                use_terrain_pred_proc=False, 
                terrain_pred_proc_eage_detect_alpha=20,
                terrain_pred_proc_terrain_adjust_alpha=[],
                use_visual = False,
                # distance of dims
                with_dis_file=False,
                terrain_zero=False,
                fluid_mean = False,
                ):

        # double_pde
        self.use_double_pde=use_double_pde

        # revised: eage_samp
        self.use_eage_samp = use_eage_samp
        self.eage_samp_random_scale = eage_samp_random_scale
        self.eage_samp_num_alpha = eage_samp_num_alpha
        self.eage_samp_name = eage_samp_name

        # revised: terrain_pred_proc
        self.use_terrain_pred_proc = use_terrain_pred_proc
        self.terrain_pred_proc_eage_detect_alpha = terrain_pred_proc_eage_detect_alpha
        self.terrain_pred_proc_terrain_adjust_alpha = \
            self._check_terrain_pred_proc_terrain_adjust_alpha(
            use_terrain_pred_proc, 
            terrain_pred_proc_terrain_adjust_alpha, 
            phy_fea_names)
        
        self.fluid_mean = fluid_mean
        
        # for gate or part conv

        super(SeaobsDataLoader, self).__init__(
            data_dir=data_dir, data_filenames=data_filenames,
            nx=nx, nz=nz, nt=nt, n_samp_pts_per_crop=n_samp_pts_per_crop,
            downsamp_x=downsamp_x, downsamp_z=downsamp_z, downsamp_t=downsamp_t, 
            normalize_output=normalize_output, normalize_hres=normalize_hres,
            return_hres=return_hres, lres_filter=lres_filter, lres_interp=lres_interp,
            phy_fea_names=phy_fea_names, swap_zx=swap_zx, use_visual=use_visual, log_folder=log_folder,
            with_dis_file=with_dis_file, terrain_zero=terrain_zero)
    
    # compare feature list and file list
    def _check_terrain_pred_proc_terrain_adjust_alpha(
            self, use_terrain_pred_proc, terrain_pred_proc_terrain_adjust_alpha, phy_fea_names):
        if use_terrain_pred_proc:
            if len(phy_fea_names) != len(terrain_pred_proc_terrain_adjust_alpha):
                raise f"the length of phy_fea_names must be the length of terrain_pred_proc_terrain_adjust_alpha"
            else:
                return terrain_pred_proc_terrain_adjust_alpha
        else:
            return []
    
    # get point coord
    def _get_point_coord(self, idx):
        if self.use_eage_samp:
            # adapt
            dataset_id, _, z_id, x_id = self._get_dim_id(idx)
            point_num = self.n_samp_pts_per_crop
            hres_crop_soeage = self.data_soeage[dataset_id,
                                            z_id:z_id+self.nz_hres,
                                            x_id:x_id+self.nx_hres]  # [d, z, x]
            # detail
            point_coord, point_eage = eage_samp_select(
                point_num=point_num, hres_crop_soeage=hres_crop_soeage, 
                nt_hres=self.nt_hres, 
                eage_samp_random_scale=self.eage_samp_random_scale, 
                eage_samp_num_alpha=self.eage_samp_num_alpha, 
                eage_samp_name=self.eage_samp_name)
            
                   
        else:
            point_coord, point_eage = super()._get_point_coord(idx)
        
        return point_coord, point_eage
    
    # vertify whether point is sea or terrain
    def _get_point_sod(self, point_coord, idx):
        if self.use_double_pde:
            dataset_id, _, z_id, x_id = self._get_dim_id(idx)
            hres_crop_sod = self.data_sod[dataset_id,
                                          z_id:z_id+self.nz_hres,
                                          x_id:x_id+self.nx_hres]  # [d, z, x]
            interp_sod = RegularGridInterpolator(
                (np.arange(self.nz_hres), np.arange(self.nx_hres)),
                values=hres_crop_sod, method='linear')
            
            lres_coord = np.stack(np.meshgrid(
                                          np.linspace(0, self.nz_hres-1, self.nz_lres),
                                          np.linspace(0, self.nx_hres-1, self.nx_lres),
                                          indexing='ij'), axis=-1)
            lres_crop_sod = interp_sod(lres_coord)

            point_sod = interp_sod(point_coord[..., 1:]).astype(np.float32)
            point_sod[point_sod!=1.0] = 0.0

            if self.use_visual_getitem:
                draw_fun = point_samp3d.DrawDuPointImageWithBg()
                self.image_generator.draw_fun = draw_fun
                npdata_list = [[point_coord[:, 2], point_coord[:, 1]], point_sod.astype(np.int64), hres_crop_sod]
                self.image_generator(npdata_list, self.image_folder, f"hres_crop_dupoint_soeage_{self.use_visual_getitem_id}")
                self.use_visual_getitem_id += 1
                
            return lres_crop_sod, point_sod
        else:
            return super()._get_point_sod(point_coord, idx)
        
    def _get_mean_std(self):
        
        if self.fluid_mean:
            shape = self.data.shape
            points = []
        
            for di in range(shape[0]):
                for zi in range(shape[3]):
                    for xi in range(shape[4]):
                        if self.data_sod[di, zi, xi] == 1:
                            points.append(self.data[di,:,:,zi,xi])

            points = np.stack(points, axis=0)

            mean = np.mean(points.astype(np.float64), axis=(0, 2)).astype(np.float32)
            std = np.std(points.astype(np.float64), axis=(0, 2)).astype(np.float32)

            for di in range(shape[0]):
                for ci in range(shape[1]):
                    for ti in range(shape[2]):
                        for zi in range(shape[3]):
                            for xi in range(shape[4]):
                                if self.data_sod[di, zi, xi] == 0:
                                    self.data[di, ci, ti, zi, xi] = mean[ci]

        else:
            mean = np.mean(self.data.astype(np.float64), axis=(0, 2, 3, 4)).astype(np.float32)
            std = np.std(self.data.astype(np.float64), axis=(0, 2, 3, 4)).astype(np.float32)
            
        return mean, std

    # pre-process incluing terrain
    def _pred_proc(self):
        if self.use_eage_samp or self.use_terrain_pred_proc or self.use_double_pde:
            multi_npdata_sod_list = []
            for data_filename in self.data_filenames:
                npdata = np.load(os.path.join(self.data_dir, data_filename))
                data_sod = npdata["sod"]
                multi_npdata_sod_list.append(data_sod)
            multi_data_sod = np.stack(multi_npdata_sod_list, axis=0)

            self.data_sod = multi_data_sod

            self.data_soeage, self.data_outexpan_soeage = self._get_multi_data_soeage_outexpan_soeage()

        x_start_id = 256

        if self.use_visual_init:
            for fea_id in range(self.data.shape[1]):
                self.image_generator.draw_fun.aspect = 1
                self.image_generator(self.data[self.visual_data_d_id, fea_id, self.visual_data_t_id][:, x_start_id : int(x_start_id + 128)], self.image_folder, f"data_fea_{fea_id}")

        if self.use_visual_init and TEST:
            for fea_id in range(self.data.shape[1]):
                hres = self.data[self.visual_data_d_id, fea_id, self.visual_data_t_id]

                lres = RegularGridInterpolator(
                    (np.arange(hres.shape[0]), np.arange(hres.shape[1])),
                    values=hres, method='linear')(np.stack(np.meshgrid(
                        np.linspace(0, hres.shape[0]-1, int(hres.shape[0] / 8)),
                        np.linspace(0, hres.shape[1]-1, int(hres.shape[1] / 4)),
                        indexing='ij'), axis=-1))
                self.image_generator.draw_fun.aspect = 2
                self.image_generator(lres[:, int(x_start_id/4) : int(x_start_id/4 + 32)], self.image_folder, f"data_fea_lres_{fea_id}")


        if self.use_terrain_pred_proc:
            self._terrain_pred_proc()
    
            if self.use_visual_init:
                for fea_id in range(self.data.shape[1]):
                    self.image_generator.draw_fun.aspect = 1
                    self.image_generator(self.data[self.visual_data_d_id, fea_id, self.visual_data_t_id][:, x_start_id : int(x_start_id + 128)], self.image_folder, f"data_fea_adjust_{fea_id}")
                    if TEST:
                        hres = self.data[self.visual_data_d_id, fea_id, self.visual_data_t_id]

                        lres = RegularGridInterpolator(
                            (np.arange(hres.shape[0]), np.arange(hres.shape[1])),
                            values=hres, method='linear')(np.stack(np.meshgrid(
                                np.linspace(0, hres.shape[0]-1, int(hres.shape[0] / 8)),
                                np.linspace(0, hres.shape[1]-1, int(hres.shape[1] / 4)),
                                indexing='ij'), axis=-1))
                        self.image_generator.draw_fun.aspect = 2
                        
                        impl = np.random.rand(*lres.shape)
                        vmin, vmax = (np.min(impl), np.max(impl))
                        vmin = vmin - (vmax-vmin) * 0.5
                        vmax = vmax + (vmax-vmin) * 0.5
                        self.image_generator(impl[:, int(x_start_id/4) : int(x_start_id/4 + 32)], self.image_folder, f"data_fea_impl_lres_{fea_id}", vmin=vmin, vmax=vmax)
                        self.image_generator(lres[:, int(x_start_id/4) : int(x_start_id/4 + 32)], self.image_folder, f"data_fea_adjust_lres_{fea_id}")

    # get outexpan soeage for processing
    def _get_multi_data_soeage_outexpan_soeage(self):
        multi_npdata_soeage_list = []
        multi_npdata_outexpan_soeage_list = []
        for dataset_id in range(len(self.data)):
            npdata_sod = self.data_sod[dataset_id]

            grid_process_fun = grid_process.SodToSoEage()
            npdata_soeage = grid_process_fun(npdata_sod)

            grid_process_fun = grid_process.SoEageExpand()
            npdata_expand_eage = grid_process_fun(npdata_soeage, expand_alpha=self.terrain_pred_proc_eage_detect_alpha)

            grid_process_fun = grid_process.ExpanSoEageToOutExpanSoEage()
            npdata_outexpan_soeage = grid_process_fun(npdata_expand_eage, npdata_sod)

            multi_npdata_soeage_list.append(npdata_soeage)
            multi_npdata_outexpan_soeage_list.append(npdata_outexpan_soeage)

        multi_npdata_soeage = np.stack(multi_npdata_soeage_list, axis=0)
        multi_npdata_outexpan_soeage = np.stack(multi_npdata_outexpan_soeage_list, axis=0)
        return multi_npdata_soeage, multi_npdata_outexpan_soeage
    
    # terrain pre-processing
    def _terrain_pred_proc(self):
        # adapt
        multi_npdata_feas = self.data
        multi_npdata_sod = self.data_sod
        multi_npdata_outexpan_soeage = self.data_outexpan_soeage

        # detail
        for dataset_id in range(self.dataset_num):
            npdata_sod = multi_npdata_sod[dataset_id]
            npdata_feas = multi_npdata_feas[dataset_id]
            npdata_outexpan_soeage = multi_npdata_outexpan_soeage[dataset_id]
            
            for fea_id in range(len(npdata_feas)):
                if self.terrain_pred_proc_terrain_adjust_alpha[fea_id] != "none":
                    npdata_fea = npdata_feas[fea_id]
                    grid_process_fun = grid_process.AdjustObsValueByArea()
                    npdata_adjust_fea = grid_process_fun(
                        npdata_fea, npdata_outexpan_soeage, npdata_sod, 
                        adjust_alpha=float(self.terrain_pred_proc_terrain_adjust_alpha[fea_id]))
                    multi_npdata_feas[dataset_id][fea_id] = npdata_adjust_fea

