import sys
import torch
from torch import nn, einsum
from einops import rearrange

sys.path.append("/home/hanpeng/learn_deep_learning/torch_net")

import transformer 

class ImNet(nn.Module):
    def __init__(self, dim, in_features, out_features, n_base_feature=16, dropout=0.2):
        super(ImNet, self).__init__()

        in_features_with_dim = dim + in_features

        self.transformer = transformer.Transformer(
            in_feas=in_features_with_dim, head_num=5, head_feas=in_features_with_dim, mlp_mid_feas=in_features_with_dim * 2,
            depth=6, dropout=dropout,
        )

    def forward(self, x):
        shape = x.shape
        x = x.reshape(int(shape[0] / 8), 8, shape[1])
        
        x = self.transformer(x)

        shape = x.shape
        x = x.reshape(int(shape[0] * shape[1]), shape[2])

        return x

def test_imnet():
    imnet = ImNet(dim=3, in_features=32, out_features=7, n_base_feature=16)
    input = torch.rand(512*8, 35)
    output = imnet(input)
    model_param_count = lambda model: sum(x.numel() for x in model.parameters())
    unet_param_count = model_param_count(imnet)
    print(f"output's shape: {output.detach().numpy().shape}")
    print(f"model's num: {unet_param_count}")

def main():
    test_imnet()

if __name__ == "__main__":
    main()