import numpy as np

def get_le_by_rho_uvw(rho, u, v, w):
    if rho.shape == u.shape == v.shape == w.shape:
        le = 1/2 * rho * (u ** 2 + v ** 2 + w ** 2)
        return le
    else:
        raise f"there must be the same shape for all parameters"
    
def get_le_by_bp_uw(b, p, u, w):
    if b.shape == p.shape == u.shape == w.shape:
        rho = p / b
        le = 1/2 * rho * (u ** 2 + w ** 2)
        return le
    else:
        raise f"there must be the same shape for all parameters"
    
def get_le_by_uw(u, w):
    if u.shape == w.shape:
        rho = 1
        le = 1/2 * rho * (u ** 2 + w ** 2)
        return le
    else:
        raise f"there must be the same shape for all parameters"
    
def get_le_by_bs_uw(b, s, u, w):
    if b.shape == s.shape == u.shape == w.shape:
        rho = 1 - 1.7 * 10 ** (-4) * (b + 273.15 - 283) + 7.6 * 10 ** (-4) * (s - 35)
        # rho = s - b
        le = 1/2 * rho * (u ** 2 + w ** 2) * 1028
        return le
    else:
        raise f"there must be the same shape for all parameters"

def get_mean_le(le):
    mean_le = np.mean(le)
    return mean_le

def get_error(le_truth, le_pred):
    acc = np.abs(le_pred - le_truth) / le_truth
    return 1-acc

def test():
    shape = [256, 128, 512]
    rho = np.random.rand(*shape)
    u   = np.random.rand(*shape)
    v   = np.random.rand(*shape)
    w   = np.random.rand(*shape)
    b   = 34 + np.random.rand(*shape)
    p   = np.random.rand(*shape)
    s   = np.random.rand(*shape)

    le1 = get_mean_le(get_le_by_rho_uvw(rho, u, v, w))
    le2 = get_mean_le(get_le_by_uw(u, w))
    le3 = get_mean_le(get_le_by_bs_uw(b, s, u, w))
    print(le1, le2, le3)

def main():
    test()

if __name__ == "__main__":
    main()