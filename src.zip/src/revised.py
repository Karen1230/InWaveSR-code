import numpy as np
import torch
import sys
import os
import json
import skimage
import argparse

current_dir = os.path.dirname(os.path.realpath(__file__))

sys.path.append(os.path.join(current_dir, "..", "meshfreeflownet"))
sys.path.append(os.path.join(current_dir, "..", "meshfreeflownet", "src"))

import dataloader_spacetime
import dataloader_multi_spacetime
import dataloader_seaobs_spacetime
import train_utils as utils
import model_select
from scipy.interpolate import RegularGridInterpolator
from local_implicit_grid import query_local_implicit_grid
from collections import defaultdict
from tqdm import tqdm

# use for bool parameter
def str2bool(v):
    if isinstance(v, bool):
        return v
    if v.lower() in ('yes', 'true', 't', 'y', '1', "True"):
        return True
    elif v.lower() in ('no', 'false', 'f', 'n', '0', "False"):
        return False
    else:
        raise argparse.ArgumentTypeError('Boolean value expected.')

def train_args_supplement(parser):
    def origin():
        parser.add_argument("--log_dir", type=str, required=True, help="log directory for run")
        parser.add_argument('--rayleigh', type=float, required=True,
                            help='Simulation Rayleigh number.')
        parser.add_argument('--prandtl', type=float, required=True,
                            help='Simulation Prandtl number.')
        
        parser.add_argument("--downsamp_xz", default=8, type=int,
                        help="down sampling factor in x and z for low resolution crop.")
        
    def revised():
        # required
        parser.add_argument("--log_dir", type=str, required=False, default="./log/ExpTem",
                            help="log directory for run")
        parser.add_argument('--rayleigh', type=float, required=False, default=1000000,
                            help='Simulation Rayleigh number.')
        parser.add_argument('--prandtl', type=float, required=False, default=1,
                            help='Simulation Prandtl number.')
        
        # modify
        parser.add_argument("--downsamp_z", default=8, type=int,
                        help="down sampling factor in z for low resolution crop.")
        parser.add_argument("--downsamp_x", default=8, type=int,
                        help="down sampling factor in x for low resolution crop.")
        
        ##### add #####
        parser.add_argument("--phy_fea_names_str", type=str, default="p, b, u, w") # "p, b, u, w" -> ["p", "b", "u", "w"]
        parser.add_argument("--train_datas_str", type=str, default="rb2d_ra1e6_s42.npz, rb2d_ra1e6_s102.npz",
                        help="names of multiple training data")
        parser.add_argument("--eval_datas_str", type=str, default="rb2d_ra1e6_s42.npz",
                        help="names of multiple evaling data")
        parser.add_argument("--swap_zx", type=str2bool, default=False, 
                        help="whether to swap z dim and x dim when load data file")
        parser.add_argument("--cuda_devices", type=str  , default="0")

        ### sod ###

        # double_pde
        parser.add_argument("--use_double_pde", type=str2bool)

        # eage_samp
        parser.add_argument("--use_eage_samp", type=str2bool)
        parser.add_argument("--eage_samp_random_scale", type=float, default=7.0)
        parser.add_argument("--eage_samp_num_alpha", type=float, default=0.5)
        parser.add_argument("--eage_samp_name", type=str, default="eage_samp_v1")

        # terrain_pred_proc
        parser.add_argument("--use_terrain_pred_proc", type=str2bool)
        parser.add_argument("--terrain_pred_proc_eage_detect_alpha", type=int, default=20)
        parser.add_argument("--terrain_pred_proc_terrain_adjust_alpha_str", type=str, default="")

        # visual
        parser.add_argument("--use_visual", type=str2bool)

        parser.add_argument("--equation_folder", type=str, default="./equation",
                        help="path to equation folder (default: ./equation)")
        parser.add_argument("--equation_file", type=str, default="convection.json",
                        help="name of equation file (default: convection.json)")
        
        # distance
        parser.add_argument("--dist_t", type=float, default=1/8)
        parser.add_argument("--dist_z", type=float, default=1/128)
        parser.add_argument("--dist_x", type=float, default=1/128)

        # model name
        parser.add_argument("--unet_name", type=str, default="meshfree_unet")
        parser.add_argument("--imnet_name", type=str, default="meshfree_imnet")
        parser.add_argument("--discriminater_name", type=str, default="att_discriminater")

        # gan
        parser.add_argument("--gan_mode", type=str2bool, default=False)
        parser.add_argument("--alpha_loss_g", type=float, default=10.0)
        parser.add_argument("--lr_D", type=float, default=1e-3, metavar="R",
                            help="learning rate of discriminater (default: 0.01)")
        parser.add_argument("--lr_scheduler_D", type=str2bool, default=False)

        # all_eval
        parser.add_argument("--all_eval_mode", type=str2bool, default=False)
        parser.add_argument("--all_eval_xres", type=int, default=512)
        parser.add_argument("--all_eval_zres", type=int, default=128)
        parser.add_argument("--all_eval_tres", type=int, default=192)

        parser.add_argument("--ssim_psnr_normalize", type=str2bool, default=True)
        parser.add_argument("--train_eval_norm_way", type=str, default="norm",
                            help="whether norm hres or denorm pred")
        parser.add_argument("--with_dis_file", type=str2bool, default=False)
        parser.add_argument("--sigmoid_pde", type=str2bool, default=False)
        parser.add_argument("--terrain_zero", type=str2bool, default=False)
        parser.add_argument("--fluid_mean", type=str2bool, default=False)
        
     
        # convection
        def set_convection_args():
            parser.set_defaults(phy_fea_names_str="p, b, u, w")
            parser.set_defaults(train_datas_str="rb2d_ra1e6_s42.npz, rb2d_ra1e6_s102.npz")
            parser.set_defaults(eval_datas_str="rb2d_ra1e6_s102.npz")
            parser.set_defaults(with_dis_file=False)
            parser.set_defaults(dist_t=1/8)
            parser.set_defaults(dist_z=1/128)
            parser.set_defaults(dist_x=1/128)
            parser.set_defaults(all_eval_xres=512)
            parser.set_defaults(all_eval_zres=128)
            parser.set_defaults(all_eval_tres=192)
            parser.set_defaults(swap_zx=True)

            # sod
            parser.set_defaults(use_double_pde=False)
            parser.set_defaults(use_eage_samp=False)
            parser.set_defaults(use_terrain_pred_proc=False)

        def set_southsea_args():
            parser.set_defaults(phy_fea_names_str="s, u, w, b, v, p, rho")
            parser.set_defaults(use_double_pde=True)
            parser.set_defaults(use_eage_samp=True)
            parser.set_defaults(eage_samp_random_scale=7.0)
            parser.set_defaults(eage_samp_num_alpha=0.2)
            parser.set_defaults(use_terrain_pred_proc=True)
            parser.set_defaults(terrain_pred_proc_terrain_adjust_alpha_str="0.5,none,none,0.2,none,0.5,0.7")
            parser.set_defaults(with_dis_file=True)
            parser.set_defaults(equation_file="isws2.json")
            parser.set_defaults(alpha_pde=0.005)
            parser.set_defaults(all_eval_xres=512)
            parser.set_defaults(all_eval_zres=128)
            parser.set_defaults(all_eval_tres=256)
            parser.set_defaults(data_folder="/home/hanpeng/south_china_sea/npz_file")
            parser.set_defaults(train_datas_str="c307.npz")
            parser.set_defaults(eval_datas_str="c307.npz")

        def set_exp(basic_log_name):
            set_southsea_args()
            # nvidia-smi
            parser.set_defaults(cuda_devices="1")
            parser.set_defaults(batch_size_per_gpu=8)
            parser.set_defaults(n_samp_pts_per_crop=512)
            parser.set_defaults(pseudo_epoch_size=3000)
            # eage sample
            parser.set_defaults(eage_samp_name="eage_samp_v2")
            parser.set_defaults(eage_samp_random_scale=7.0)
            parser.set_defaults(eage_samp_num_alpha=0.2)
            # model
            parser.set_defaults(unet_name="att_unet_fft")
            parser.set_defaults(terrain_zero=False)
            parser.set_defaults(imnet_name="res_imnet")
            # all_eval_mode
            parser.set_defaults(all_eval_mode=True)
            # log
            parser.set_defaults(log_dir=basic_log_name)
            # visual
            parser.set_defaults(use_visual=True)
            parser.set_defaults(lr=1e-3)
            parser.set_defaults(fluid_mean=True)

        def set_satob():
            # origin
            parser.set_defaults(downsamp_t=4)
            parser.set_defaults(downsamp_z=4)
            parser.set_defaults(downsamp_x=1)
            parser.set_defaults(unet_name="att_unet_fft_light")
            parser.set_defaults(nt=16)
            parser.set_defaults(nz=16)
            parser.set_defaults(nx=4)
            parser.set_defaults(phy_fea_names_str="b")
            parser.set_defaults(terrain_pred_proc_terrain_adjust_alpha_str="0.5")
            parser.set_defaults(equation_file="isws_none.json")
            parser.set_defaults(with_dis_file=False)
            parser.set_defaults(train_datas_str="c115.npz,c158.npz,c182.npz,c308.npz,c332.npz,c383.npz,c437.npz")

            def microtrain():
                # satob
                parser.set_defaults(data_folder="/home/hanpeng/satob_isw/npz_files")
                parser.set_defaults(train_datas_str=(
                    "obsat_t0_11100.npz, obsat_t0_13700.npz, obsat_t0_22000.npz, obsat_t0_16400.npz,"
                    "obsat_t0_18000.npz, obsat_t0_22000.npz, obsat_t0_30600.npz, obsat_t0_32500.npz,"
                    "obsat_t0_36300.npz, obsat_t0_40800.npz, obsat_t0_12500.npz, obsat_t0_12500.npz,"
                    "obsat_t0_12500.npz, obsat_t0_12500.npz, obsat_t0_12500.npz, obsat_t0_12500.npz"))
                parser.set_defaults(eval_datas_str="obsat_t0_12500.npz")
                parser.set_defaults(resume="/home/hanpeng/space_time_pde_iw-master/log/Exp_satob/checkpoint_latest.pth.tar_pdenet_050.pth.tar")
                parser.set_defaults(all_eval_tres=512)
                parser.set_defaults(all_eval_zres=16)
                parser.set_defaults(all_eval_xres=4)

            # microtrain()

        def set_test(basic_log_name):
            parser.set_defaults(epochs=1)
            parser.set_defaults(pseudo_epoch_size=1000)
            parser.set_defaults(n_samp_pts_per_crop=512)
            parser.set_defaults(batch_size_per_gpu=6)
            parser.set_defaults(log_dir=f"{basic_log_name}_tem")       
            parser.set_defaults(use_visual=False)
            # parser.set_defaults(all_eval_tres=32)
            # parser.set_defaults(all_eval_tres=32)

            

        # basic_log_name
        basic_log_name = "./log/Exp"
        set_exp(basic_log_name)
        # set_satob()
        set_test(basic_log_name)
    
    revised()

def evaluation_args_supplement(parser):
    def origin():
        parser.add_argument("--eval_downsamp_t", default=4, type=int, required=True, 
                        help="down sampling factor in t for low resolution crop.")
        parser.add_argument("--eval_downsamp_xz", default=4, type=int, required=True,
                            help="down sampling factor in x and z for low resolution crop.")
        parser.add_argument('--ckpt', type=str, required=True, help="path to checkpoint")
        parser.add_argument("--eval_dataset", type=str, required=True)
        parser.add_argument('--rayleigh', type=float, required=True,
                            help='Simulation Rayleigh number.')
        parser.add_argument('--prandtl', type=float, required=True,
                            help='Simulation Prandtl number.')

    def revised():
        # required
        parser.add_argument("--eval_downsamp_t", default=4, type=int, required=False, 
                        help="down sampling factor in t for low resolution crop.")
        parser.add_argument("--eval_downsamp_z", default=8, type=int, required=False,
                            help="down sampling factor in x and z for low resolution crop.")
        parser.add_argument("--eval_downsamp_x", default=8, type=int, required=False,
                            help="down sampling factor in x and z for low resolution crop.")
        parser.add_argument('--ckpt', type=str, required=False, help="path to checkpoint")  
        parser.set_defaults(ckpt="./log/ExpTem/checkpoint_latest.pth.tar_pdenet_best_loss.pth.tar")
        parser.add_argument("--eval_dataset", type=str, required=False)
        parser.add_argument('--rayleigh', type=float, required=False, default=1000000,
                            help='Simulation Rayleigh number.')
        parser.add_argument('--prandtl', type=float, required=False, default=1,
                            help='Simulation Prandtl number.')
        parser.add_argument("--cuda_devices", type=str  , default="0")
        parser.add_argument("--eval_data_folder", type=str, default="./data",
                        help="path to data folder in evaluation(default: ./data)")
        
        # set

        # convection
        def convection():
            parser.set_defaults(eval_dataset="rb2d_ra1e6_s42.npz")
            parser.set_defaults(eval_xres=512)
            parser.set_defaults(eval_zres=128)
            parser.set_defaults(eval_tres=192)

        # internal waves
        def set_southsea_args():
            parser.set_defaults(eval_dataset="c307.npz")
            parser.set_defaults(eval_data_folder="/home/hanpeng/south_china_sea/npz_file")
            parser.set_defaults(eval_xres=512)
            parser.set_defaults(eval_zres=128)
            parser.set_defaults(eval_tres=256)

        def set_exp(basic_log_name):
            set_southsea_args()
            parser.set_defaults(cuda_devices="1")
            parser.set_defaults(ckpt=f"{basic_log_name}/checkpoint_latest.pth.tar_pdenet_best_loss.pth.tar")
            parser.set_defaults(save_path=f"{basic_log_name}/eval")
            parser.set_defaults(eval_pseudo_batch_size=1024)
            
        def set_satob():
            parser.set_defaults(eval_downsamp_t=4)
            parser.set_defaults(eval_downsamp_z=4)
            parser.set_defaults(eval_downsamp_x=1)

            parser.set_defaults(eval_xres=4)
            parser.set_defaults(eval_zres=16)
            parser.set_defaults(eval_tres=512)
            parser.set_defaults(eval_data_folder="/home/hanpeng/satob_isw/npz_files")
            parser.set_defaults(eval_dataset="obsat_t0_12500.npz")

        def set_test(basic_log_name):
            parser.set_defaults(eval_tres=32)
            parser.set_defaults(ckpt=f"{basic_log_name}_tem/checkpoint_latest.pth.tar_pdenet_best_loss.pth.tar")
            parser.set_defaults(save_path=f"{basic_log_name}_tem/eval")

        # basic_log_name
        basic_log_name = "./log/Exp_satob"
        set_exp(basic_log_name)
        # set_satob()
        # set_test(basic_log_name)

        # parser.set_defaults(eval_tres=16)

    revised()

# "a, b, c, d" -> ["a", "b", "c", "d"]
def train_args_transform(args):
    args.phy_fea_names = args.phy_fea_names_str.replace(" ", "").split(",")
    args.train_datas = args.train_datas_str.replace(" ", "").split(",")
    args.eval_datas = args.eval_datas_str.replace(" ", "").split(",")
    args.terrain_pred_proc_terrain_adjust_alpha = \
        args.terrain_pred_proc_terrain_adjust_alpha_str.replace(" ", "").split(",")

def train_trainset_loader(args):
    trainset = dataloader_seaobs_spacetime.SeaobsDataLoader(
        data_dir=args.data_folder,
        nx=args.nx, nz=args.nz, nt=args.nt, n_samp_pts_per_crop=args.n_samp_pts_per_crop,
        downsamp_x=args.downsamp_x, downsamp_z=args.downsamp_z, downsamp_t=args.downsamp_t,
        normalize_output=args.normalize_channels, return_hres=False,
        lres_filter=args.lres_filter, lres_interp=args.lres_interp,
        # the list of physics features's names
        phy_fea_names=args.phy_fea_names,
        # whether to swap z dim and x dim when load data file
        swap_zx = args.swap_zx,
        # revised: multi dataset
        data_filenames=args.train_datas,
        # revised: double_pde
        use_double_pde = args.use_double_pde,
        # revised: eage_samp
        use_eage_samp=args.use_eage_samp, 
        eage_samp_random_scale=args.eage_samp_random_scale, 
        eage_samp_num_alpha=args.eage_samp_num_alpha,
        eage_samp_name=args.eage_samp_name,
        # revised: terrain_pred_proc
        use_terrain_pred_proc=args.use_terrain_pred_proc, 
        terrain_pred_proc_eage_detect_alpha=args.terrain_pred_proc_eage_detect_alpha,
        terrain_pred_proc_terrain_adjust_alpha=args.terrain_pred_proc_terrain_adjust_alpha,
        # visual
        use_visual = args.use_visual,
        # log_folder
        log_folder=args.log_dir,
        # whether npz file includes information of distance
        with_dis_file=args.with_dis_file,
        terrain_zero = args.terrain_zero,
        fluid_mean = args.fluid_mean

    )
    return trainset

def all_dataset_loader(args, eval_xres, eval_zres, eval_tres, downsamp_x, downsamp_z, downsamp_t, data_filenames, data_folder):
    ### train ###
    # args.all_eval_xres, args.all_eval_zres, args.all_eval_tres,
    # args.downsamp_x, args.downsamp_z, args.downsamp_t,
    # args.eval_datas

    ### eval ###
    # args.eval_xres, args.eval_zres, args.eval_tres,
    # args.eval_downsamp_x, args.eval_downsamp_z, args.eval_downsamp_t,
    # [args.eval_dataset]

    if len(data_filenames) != 1:
        raise "thr length of data_filenames must be 1 if use all eval"

    dataset = dataloader_seaobs_spacetime.SeaobsDataLoader(
        data_dir=data_folder,
        nx=eval_xres, nz=eval_zres, nt=eval_tres, n_samp_pts_per_crop=1,
        lres_interp=args.lres_interp, lres_filter=args.lres_filter, 
        downsamp_x=downsamp_x, downsamp_z=downsamp_z, downsamp_t=downsamp_t,
        normalize_output=args.normalize_channels, return_hres=True,
        phy_fea_names=args.phy_fea_names, swap_zx = args.swap_zx, 
        data_filenames=data_filenames,  
        # revised: terrain_pred_proc
        use_terrain_pred_proc=args.use_terrain_pred_proc, 
        terrain_pred_proc_eage_detect_alpha=args.terrain_pred_proc_eage_detect_alpha,
        terrain_pred_proc_terrain_adjust_alpha=args.terrain_pred_proc_terrain_adjust_alpha,
        fluid_mean = args.fluid_mean
    )
    return dataset

def evaluation_dataset_loader(args):
    def origin():
        dataset = dataloader_spacetime.RB2DataLoader(
            data_dir=args.data_folder, data_filename=args.eval_dataset,
            nx=args.eval_xres, nz=args.eval_zres, nt=args.eval_tres, n_samp_pts_per_crop=1,
            lres_interp=args.lres_interp, lres_filter=args.lres_filter, 
            downsamp_x=args.eval_downsamp_x, downsamp_z=args.eval_downsamp_z, downsamp_t=args.eval_downsamp_t,
            normalize_output=args.normalize_channels, return_hres=True
        )
        return dataset

    def revised_add_phy_fea_names():
        dataset = dataloader_spacetime.RB2DataLoader(
            data_dir=args.data_folder, data_filename=args.eval_dataset,
            nx=args.eval_xres, nz=args.eval_zres, nt=args.eval_tres, n_samp_pts_per_crop=1,
            lres_interp=args.lres_interp, lres_filter=args.lres_filter, 
            downsamp_x=args.eval_downsamp_x, downsamp_z=args.eval_downsamp_z, downsamp_t=args.eval_downsamp_t,
            normalize_output=args.normalize_channels, return_hres=True,
            # revised
            phy_fea_names=args.phy_fea_names, swap_zx = args.swap_zx
        )
        return dataset
    
    def revised_multi_data():
        dataset = dataloader_multi_spacetime.RB2MultiDataLoader(
            data_dir=args.data_folder,
            nx=args.eval_xres, nz=args.eval_zres, nt=args.eval_tres, n_samp_pts_per_crop=1,
            lres_interp=args.lres_interp, lres_filter=args.lres_filter, 
            downsamp_x=args.eval_downsamp_x, downsamp_z=args.eval_downsamp_z, downsamp_t=args.eval_downsamp_t,
            normalize_output=args.normalize_channels, return_hres=True,
            phy_fea_names=args.phy_fea_names, swap_zx = args.swap_zx, 
            # revised
            data_filenames=[args.eval_dataset]
        )
        return dataset
    
    def revised_seaobs():
        dataset = all_dataset_loader(args, args.eval_xres, args.eval_zres, args.eval_tres,
                                     args.eval_downsamp_x, args.eval_downsamp_z, args.eval_downsamp_t,
                                     [args.eval_dataset], args.eval_data_folder)
        return dataset

    return revised_seaobs()

def train_all_dataset_loader(args):
    dataset = all_dataset_loader(args, args.all_eval_xres, args.all_eval_zres, args.all_eval_tres,
                                 args.downsamp_x, args.downsamp_z, args.downsamp_t,
                                 args.eval_datas, args.data_folder)
    return dataset

def train_evalset_loader(args):
    def origin():
        evalset = dataloader_spacetime.RB2DataLoader(
            data_dir=args.data_folder, data_filename=args.eval_data,
            nx=args.nx, nz=args.nz, nt=args.nt, n_samp_pts_per_crop=args.n_samp_pts_per_crop,
            downsamp_x=args.downsamp_x, downsamp_z=args.downsamp_z, downsamp_t=args.downsamp_t,
            normalize_output=args.normalize_channels, return_hres=True,
            lres_filter=args.lres_filter, lres_interp=args.lres_interp,
        )
        return evalset

    def revised_add_phy_fea_names():
        evalset = dataloader_spacetime.RB2DataLoader(
            data_dir=args.data_folder, data_filename=args.eval_data,
            nx=args.nx, nz=args.nz, nt=args.nt, n_samp_pts_per_crop=args.n_samp_pts_per_crop,
            downsamp_x=args.downsamp_x, downsamp_z=args.downsamp_z, downsamp_t=args.downsamp_t,
            normalize_output=args.normalize_channels, return_hres=True,
            lres_filter=args.lres_filter, lres_interp=args.lres_interp,
            # revised
            phy_fea_names=args.phy_fea_names, swap_zx = args.swap_zx
        )
        return evalset
    
    def revised_multi_data():
        evalset = dataloader_multi_spacetime.RB2MultiDataLoader(
            data_dir=args.data_folder, 
            nx=args.nx, nz=args.nz, nt=args.nt, n_samp_pts_per_crop=args.n_samp_pts_per_crop,
            downsamp_x=args.downsamp_x, downsamp_z=args.downsamp_z, downsamp_t=args.downsamp_t,
            normalize_output=args.normalize_channels, return_hres=True,
            lres_filter=args.lres_filter, lres_interp=args.lres_interp,
            phy_fea_names=args.phy_fea_names, swap_zx = args.swap_zx,
            # revised
            data_filenames=args.eval_datas
        )
        return evalset
    def revised_seaobs():
        evalset = dataloader_seaobs_spacetime.SeaobsDataLoader(
            data_dir=args.data_folder, 
            nx=args.nx, nz=args.nz, nt=args.nt, n_samp_pts_per_crop=args.n_samp_pts_per_crop,
            downsamp_x=args.downsamp_x, downsamp_z=args.downsamp_z, downsamp_t=args.downsamp_t,
            normalize_output=args.normalize_channels, return_hres=True,
            lres_filter=args.lres_filter, lres_interp=args.lres_interp,
            phy_fea_names=args.phy_fea_names, swap_zx = args.swap_zx,
            data_filenames=args.eval_datas,
            # revised: terrain_pred_proc
            use_terrain_pred_proc=args.use_terrain_pred_proc, 
            terrain_pred_proc_eage_detect_alpha=args.terrain_pred_proc_eage_detect_alpha,
            terrain_pred_proc_terrain_adjust_alpha=args.terrain_pred_proc_terrain_adjust_alpha,
            fluid_mean = args.fluid_mean
        )
        return evalset

    return revised_seaobs()

def evaluation_pde_layer_foward(args, query_coord_batch, pde_layer, phys_channels, res_dict):
    def origin():
        pred_value, residue_dict = pde_layer(query_coord_batch, return_residue=True)
        pred_value = pred_value.detach().cpu().numpy()
        for key in residue_dict.keys():
            residue_dict[key] = residue_dict[key].detach().cpu().numpy()
        for name, chan_id in zip(phys_channels, range(4)):
            res_dict[name].append(pred_value[..., chan_id])  # [b, pb]
        for name, val in residue_dict.items():
            res_dict[name].append(val[..., 0])   # [b, pb]

    def revised():
        pred_value = pde_layer(query_coord_batch, return_residue=False)
        pred_value = pred_value.detach().cpu().numpy()
        for name, chan_id in zip(phys_channels, range(len(args.phy_fea_names))):
            res_dict[name].append(pred_value[..., chan_id])  # [b, pb]

    revised()

def create_unet(args, igres):
    def origin():
        from adjust_unet3d import UNet3d
        unet = UNet3d(in_features=4, out_features=args.lat_dims, igres=igres,
                  nf=args.unet_nf, mf=args.unet_mf)
        return unet

    def revised_add_fea_num():
        from adjust_unet3d import UNet3d
        in_features = len(args.phy_fea_names)
        unet = UNet3d(out_features=args.lat_dims, igres=igres,
                  nf=args.unet_nf, mf=args.unet_mf,
                  # revised
                  in_features=in_features)
        return unet
    
    def revised_add_get_by_name():
        in_features = len(args.phy_fea_names)
        unet = model_select.unet_select(args.unet_name, in_features, args.lat_dims, igres)
        return unet

    return revised_add_get_by_name()

def create_imnet(args, NONLINEARITIES):
    def origin():
        from implicit_net import ImNet
        imnet = ImNet(dim=3, in_features=args.lat_dims, out_features=4, nf=args.imnet_nf, 
                  activation=NONLINEARITIES[args.nonlin])
        return imnet

    def revised():
        from implicit_net import ImNet
        out_features = len(args.phy_fea_names)
        imnet = ImNet(dim=3, in_features=args.lat_dims, nf=args.imnet_nf, 
                  activation=NONLINEARITIES[args.nonlin], 
                  # revised
                  out_features=out_features)
        return imnet
    
    def revised_add_get_by_name():
        in_features = len(args.phy_fea_names)
        imnet = model_select.imnet_select(args.imnet_name, args.lat_dims, in_features, NONLINEARITIES[args.nonlin])
        return imnet

    return revised_add_get_by_name()

def create_discriminater(args):
    discriminater = model_select.discriminater_select(
        args.discriminater_name, phy_fea_num=len(args.phy_fea_names))
    return discriminater

def train_get_rb2_pde_layer(args, get_rb2_pde_layer, mean, std, eqn_names, eqn_strs):
    def origin():
        pde_layer = get_rb2_pde_layer(mean=mean, std=std,
            t_crop=args.nt*0.125, z_crop=args.nz*(1./128), x_crop=args.nx*(1./128), prandtl=args.prandtl, rayleigh=args.rayleigh,
            use_continuity=args.use_continuity)
        return pde_layer

    def revised_add_phy_fea_names():
        pde_layer = get_rb2_pde_layer(mean=mean, std=std,
            t_crop=args.nt*0.125, z_crop=args.nz*(1./128), x_crop=args.nx*(1./128), prandtl=args.prandtl, rayleigh=args.rayleigh,
            use_continuity=args.use_continuity, 
            # revised
            out_vars=args.phy_fea_names_str
        )
        return pde_layer

    def revised_add_eqn():
        pde_layer = get_rb2_pde_layer(mean=mean, std=std,
            t_crop=args.nt*0.125, z_crop=args.nz*(1./128), x_crop=args.nx*(1./128), prandtl=args.prandtl, rayleigh=args.rayleigh,
            use_continuity=args.use_continuity, 
            out_vars=args.phy_fea_names_str,
            # revised
            eqn_names=eqn_names, eqn_strs=eqn_strs
        )
        return pde_layer
    def revised_add_dim_dist():
        pde_layer = get_rb2_pde_layer(mean=mean, std=std,
            t_crop=(args.nt-1)*args.dist_t, z_crop=(args.nz-1)*args.dist_z, x_crop=(args.nx-1)*args.dist_x, 
            prandtl=args.prandtl, rayleigh=args.rayleigh,
            use_continuity=args.use_continuity, 
            out_vars=args.phy_fea_names_str,
            # revised
            eqn_names=eqn_names, eqn_strs=eqn_strs,
            hres_nt=args.nt, hres_nz=args.nz, hres_nx=args.nx, 
            dist_t=args.dist_t, dist_z=args.dist_z, dist_x=args.dist_x, 
            with_dis_file=args.with_dis_file
        )
        return pde_layer

    return revised_add_dim_dist()

def evaluation_get_rb2_pde_layer(args, get_rb2_pde_layer, mean, std, eqn_names, eqn_strs):
    def origin():
        pde_layer = get_rb2_pde_layer(mean=mean, std=std, prandtl=args.prandtl, rayleigh=args.rayleigh)
        return pde_layer

    def revised():
        pde_layer = get_rb2_pde_layer(mean=mean, std=std, prandtl=args.prandtl, rayleigh=args.rayleigh, 
            # revised
            out_vars=args.phy_fea_names_str)
        return pde_layer
    
    def revised_add_eqn():
        pde_layer = get_rb2_pde_layer(mean=mean, std=std, prandtl=args.prandtl, rayleigh=args.rayleigh, 
            out_vars=args.phy_fea_names_str,
            # revised
            eqn_names=eqn_names, eqn_strs=eqn_strs
            )
        
        return pde_layer
    
    def revised_add_dim_dist():
        pde_layer = get_rb2_pde_layer(
            mean=mean, std=std,
            t_crop=(args.nt-1)*args.dist_t, z_crop=(args.nz-1)*args.dist_z, x_crop=(args.nx-1)*args.dist_x, 
            prandtl=args.prandtl, rayleigh=args.rayleigh,
            use_continuity=args.use_continuity, 
            out_vars=args.phy_fea_names_str,
            # revised
            eqn_names=eqn_names, eqn_strs=eqn_strs
        )
        return pde_layer

    return revised_add_dim_dist()

def dataloader_spacetime_get_data(npdata, phy_fea_names):
    def origin():
        data = np.stack([npdata['p'], npdata['b'], npdata['u'], npdata['w']], axis=0)
        return data
        
    def revised_add_phy_fea_names():
        data_list = [npdata[phy_fea_name] for phy_fea_name in phy_fea_names]
        data = np.stack(data_list, axis=0)
        return data
    
    return revised_add_phy_fea_names()

def load_equation(args):
    def origin():
        pass

    def revised():
        with open(os.path.join(args.equation_folder, args.equation_file), "r") as file:
            equation_str = file.read()
            equation_dict = json.loads(equation_str)

        eqn_names = []
        eqn_strs = []

        for eqn_name, eqn_str in equation_dict.items():
            eqn_names.append(eqn_name)
            eqn_strs.append(eqn_str)

        return eqn_names, eqn_strs

    return revised()

def fea_npdata_ssim(fea_npdata1, fea_npdata2, normalize=True):
    # if fea_npdata1.dtype != np.float32 or fea_npdata2.dtype != np.float32:
    #     warn(f"feature_data is best represented as type of numpy float 32")
    if fea_npdata1.shape != fea_npdata2.shape:
        raise f"fea_npdata1's shape is not equal to eature_data2's shape"
    if normalize==True:
        max_value = max(np.max(fea_npdata1), np.max(fea_npdata2))
        min_value = min(np.min(fea_npdata1), np.min(fea_npdata2))
        fea_npdata1 = (fea_npdata1 - min_value) / (max_value - min_value)
        fea_npdata2 = (fea_npdata2 - min_value) / (max_value - min_value)
        if fea_npdata1.shape[-1] > 7:
            ssim_value = skimage.metrics.structural_similarity(fea_npdata1, fea_npdata2, data_range=1)
        else:
            ssim_value = skimage.metrics.structural_similarity(
                fea_npdata1.transpose(2, 1, 0), 
                fea_npdata2.transpose(2, 1, 0),
                data_range=1, channel_axis=0)
        return ssim_value
    else:
        sim_value = skimage.metrics.structural_similarity(fea_npdata1, fea_npdata2)
        return sim_value

def fea_npdata_psnr(fea_npdata1, fea_npdata2, normalize=True):
    # if fea_npdata1.dtype != np.float32 or fea_npdata2.dtype != np.float32:
    #     warn(f"feature_data is best represented as type of numpy float 32")
    if fea_npdata1.shape != fea_npdata2.shape:
        raise f"fea_npdata1's shape is not equal to eature_data2's shape"
    if normalize==True:
        max_value = max(np.max(fea_npdata1), np.max(fea_npdata2))
        min_value = min(np.min(fea_npdata1), np.min(fea_npdata2))
        fea_npdata1 = (fea_npdata1 - min_value) / (max_value - min_value)
        fea_npdata2 = (fea_npdata2 - min_value) / (max_value - min_value)
        if fea_npdata1.shape[-1] > 7:
            psnr_value = skimage.metrics.peak_signal_noise_ratio(fea_npdata1, fea_npdata2, data_range=1)
        else:
            psnr_value = skimage.metrics.peak_signal_noise_ratio(
                fea_npdata1.transpose(2, 1, 0), 
                fea_npdata2.transpose(2, 1, 0),
                data_range=1)
        return psnr_value
    else:
        psnr_value = skimage.metrics.peak_signal_noise_ratio(fea_npdata1, fea_npdata2)
        return psnr_value

def get_average_psnr_ssim(hres, pred, phy_fea_names, normalize=True):
    ssim_value_list = []
    psnr_value_list = []
    for fea_id, fea_name in enumerate(phy_fea_names):
        ssim_value = fea_npdata_ssim(hres[fea_id], pred[fea_id], normalize)
        psnr_value = fea_npdata_psnr(hres[fea_id], pred[fea_id], normalize)

        ssim_value_list.append(ssim_value)
        psnr_value_list.append(psnr_value)

    average_ssim_value = sum(ssim_value_list) / len(ssim_value_list)
    average_psnr_value = sum(psnr_value_list) / len(psnr_value_list)
    return average_ssim_value, average_psnr_value

def log_ind(log_dir, hres, pred, interp_hres, phy_fea_names, normalize=True):
    os.makedirs(log_dir, exist_ok=True)
    logger = utils.get_logger(log_dir=log_dir)

    logger.info("\nmodel with ground truth")
    for fea_id, fea_name in enumerate(phy_fea_names):
        ssim_value = fea_npdata_ssim(hres[fea_id], pred[fea_id], normalize)
        psnr_value = fea_npdata_psnr(hres[fea_id], pred[fea_id], normalize)
        logger.info(f"{fea_name}: ssim: {ssim_value}, psnr: {psnr_value}")

    logger.info("\ninterp hres with ground truth")
    for fea_id, fea_name in enumerate(phy_fea_names):
        ssim_value = fea_npdata_ssim(hres[fea_id], interp_hres[fea_id], normalize)
        psnr_value = fea_npdata_psnr(hres[fea_id], interp_hres[fea_id], normalize)
        logger.info(f"{fea_name}: ssim: {ssim_value}, psnr: {psnr_value}")


def get_interp_hres_grid(args, lres_grid):

    hres_nt, hres_nz, hres_nx = args.eval_tres, args.eval_zres, args.eval_xres
    lres_nt = int(hres_nt / args.eval_downsamp_t)
    lres_nz = int(hres_nz / args.eval_downsamp_z)
    lres_nx = int(hres_nx / args.eval_downsamp_x)

    interp_fun = RegularGridInterpolator(
        (np.arange(lres_nt), np.arange(lres_nz), np.arange(lres_nx)),
        values=lres_grid.transpose(1, 2, 3, 0), method="linear")
    
    hres_coord = np.stack(np.meshgrid(np.linspace(0, lres_nt-1, hres_nt),
                                      np.linspace(0, lres_nz-1, hres_nz),
                                      np.linspace(0, lres_nx-1, hres_nx),
                                      indexing="ij"), axis=-1)
    
    hres_grid = interp_fun(hres_coord).transpose(3, 0, 1, 2) 
    hres_grid = hres_grid.astype(np.float32)

    return hres_grid

def get_interp3_hres_grid(args, lres_grid):

    hres_nt, hres_nz, hres_nx = args.eval_tres, args.eval_zres, args.eval_xres
    lres_nt = int(hres_nt / args.eval_downsamp_t)
    lres_nz = int(hres_nz / args.eval_downsamp_z)
    lres_nx = int(hres_nx / args.eval_downsamp_x)

    interp_fun = RegularGridInterpolator(
        (np.arange(lres_nt), np.arange(lres_nz), np.arange(lres_nx)),
        values=lres_grid.transpose(1, 2, 3, 0), method="quintic")
    
    hres_coord = np.stack(np.meshgrid(np.linspace(0, lres_nt-1, hres_nt),
                                      np.linspace(0, lres_nz-1, hres_nz),
                                      np.linspace(0, lres_nx-1, hres_nx),
                                      indexing="ij"), axis=-1)
    
    hres_grid = interp_fun(hres_coord).transpose(3, 0, 1, 2) 
    hres_grid = hres_grid.astype(np.float32)

    return hres_grid

def evaluation_evaluate_feat_grid(args, pde_layer, latent_grid, t_seq, z_seq, x_seq, mins, maxs, pseudo_batch_size, use_tqdm=True):
    def get_phys_channels():
        def origin():
            phys_channels = ["p", "b", "u", "w"]
            return phys_channels

        def revised():
            return args.phy_fea_names

        return revised()

    """Evaluate latent feature grid at fixed intervals.

    Args:
        pde_layer: PDELayer instance where fwd_fn has been defined.
        latent_grid: latent feature grid of shape [batch, T, Z, X, C]
        t_seq: flat torch array of t-coordinates to evaluate
        z_seq: flat torch array of z-coordinates to evaluate
        x_seq: flat torch array of x-coordinates to evaluate
        mins: flat torch array of len 3 for min coords of t, z, x
        maxs: flat torch array of len 3 for max coords of t, z, x
        pseudo_batch_size, int, size of pseudo batch during eval
    Returns:
        res_dict: result dict.
    """
    device = latent_grid.device
    nb = latent_grid.shape[0]
    phys_channels = get_phys_channels()
    phys2id = dict(zip(phys_channels, range(len(phys_channels))))

    query_coord = torch.stack(torch.meshgrid(t_seq, z_seq, x_seq), axis=-1)  # [nt, nz, nx, 3]

    nt, nz, nx, _ = query_coord.shape
    query_coord = query_coord.reshape([-1, 3]).to(device)
    n_query  = query_coord.shape[0]

    res_dict = defaultdict(list)

    n_iters = int(np.ceil(n_query/pseudo_batch_size))

    # recised
    if use_tqdm:
        range_n_iters = tqdm(range(n_iters))
    else: 
        range_n_iters = range(n_iters)

    for idx in range_n_iters:
        sid = idx * pseudo_batch_size
        eid = min(sid+pseudo_batch_size, n_query)
        query_coord_batch = query_coord[sid:eid]
        query_coord_batch = query_coord_batch[None].expand(*(nb, eid-sid, 3))  # [nb, eid-sid, 3]

        evaluation_pde_layer_foward(args, query_coord_batch, pde_layer, phys_channels, res_dict)

    for key in res_dict.keys():
        res_dict[key] = (np.concatenate(res_dict[key], axis=1)
                         .reshape([nb, len(t_seq), len(z_seq), len(x_seq)]))[0]
    return res_dict

def evaluation_model_inference(args, lres, lres_sod, pde_layer, unet, imnet, device, eval_tres, eval_zres, eval_xres, eval_pseudo_batch_size, use_tqdm=True):

    # evaluate
    latent_grid = unet(torch.tensor(lres, dtype=torch.float32)[None].to(device), torch.tensor(lres_sod, dtype=torch.float32)[None].to(device))
    latent_grid = latent_grid.permute(0, 2, 3, 4, 1)  # [batch, T, Z, X, C]

    # create evaluation grid
    t_max = float(eval_tres/args.nt)
    z_max = float(eval_zres/args.nz)
    x_max = float(eval_xres/args.nx)

    # layout query points for the desired slices
    eps = 1e-6
    t_seq = torch.linspace(eps, t_max-eps, eval_tres)  # temporal sequences
    z_seq = torch.linspace(eps, z_max-eps, eval_zres)  # z sequences
    x_seq = torch.linspace(eps, x_max-eps, eval_xres)  # x sequences

    mins = torch.zeros(3, dtype=torch.float32, device=device)
    maxs = torch.tensor([t_max, z_max, x_max], dtype=torch.float32, device=device)

    # define lambda function for pde_layer
    fwd_fn = lambda points: query_local_implicit_grid(imnet, latent_grid, points, mins, maxs)

    # update pde layer and compute predicted values + pde residues
    pde_layer.update_forward_method(fwd_fn)

    res_dict = evaluation_evaluate_feat_grid(args, pde_layer, latent_grid, t_seq, z_seq, x_seq, mins, maxs,
                                  eval_pseudo_batch_size, use_tqdm)

    return res_dict

def export_video(args, res_dict, hres, lres, dataset):
    """Export inference result as a video.
    """
    def get_phys_channels():
        def origin():
            phys_channels = ["p", "b", "u", "w"]
            return phys_channels

        def revised():
            return args.phy_fea_names

        return revised()
    phys_channels = get_phys_channels()
    if dataset:
        # hres = dataset.denormalize_grid(hres.copy())
        lres = dataset.denormalize_grid(lres.copy())
        pred = np.stack([res_dict[key] for key in phys_channels], axis=0)
        pred = dataset.denormalize_grid(pred)
        return lres, pred

def get_hres_lred_pred(args, dataset, pde_layer, unet, imnet, device, eval_tres, eval_zres, eval_xres, eval_pseudo_batch_size, use_tqdm=True):

    # extract data
    hres, lres, _, _, _, _, _, lres_sod = dataset[0]

    res_dict = evaluation_model_inference(args, lres, lres_sod, pde_layer, unet, imnet, device, eval_tres, eval_zres, eval_xres, eval_pseudo_batch_size, use_tqdm)
    # save video
    lres, pred = export_video(args, res_dict, hres, lres, dataset)
    return hres, lres, pred

def create_ind(args):
    if args.resume:
        with open(os.path.join(os.path.dirname(args.ckpt), "ind.json"), 'r') as fh:
            ind_dict = json.load(fh)
    else:
        ind_dict = {
            "loss": [],
            "ssim": [],
            "psnr": [],
        }
    with open(os.path.join(args.log_dir, "ind.json"), 'w') as fh:
        json.dump(ind_dict, fh, indent=2)

def updata_ind(args, loss, average_ssim_value, average_psnr_value):
    with open(os.path.join(args.log_dir, "ind.json"), 'r') as fh:
        ind_dict = json.load(fh)

    ind_dict["loss"].append(loss*args.batch_size)
    ind_dict["ssim"].append(average_ssim_value)
    ind_dict["psnr"].append(average_psnr_value)

    with open(os.path.join(args.log_dir, "ind.json"), 'w') as fh:
        json.dump(ind_dict, fh, indent=2)
