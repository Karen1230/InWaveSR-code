import sys
import os
import torch.nn as nn
current_dir = os.path.dirname(os.path.realpath(__file__))

def unet_select(unet_name="meshfree_unet", in_fea_num=4, out_fea_num=32, grid=(4, 16, 16)):
    if unet_name=="meshfree_unet":
        sys.path.append(os.path.join(current_dir, "..", "meshfreeflownet", "src"))
        from unet3d import UNet3d
        unet = UNet3d(
            in_features=in_fea_num, out_features=out_fea_num, igres=grid,
            nf=16, mf=256)
        return unet
    
    elif unet_name=="trans_unet":
        if out_fea_num == 32:
            sys.path.append(os.path.join(current_dir, "..", "transflownet"))
            print()
            from trans_unet import TransUNet3d
            unet = TransUNet3d(in_fea_num=in_fea_num)
            return unet
        else:
            raise "trans_unet's out_fea_num must be 32"
        
    elif unet_name=="trans_unet2":
        if out_fea_num == 32:
            sys.path.append(os.path.join(current_dir, "..", "transflownet"))
            print()
            from trans_unet2 import TransUNet3d2
            unet = TransUNet3d2(in_fea_num=in_fea_num)
            return unet
        else:
            raise "trans_unet's out_fea_num must be 32"
    
    elif unet_name=="gan_att_unet":
        sys.path.append(os.path.join(current_dir, "..", "gan"))
        from gan_att_unet import Unet3d
        unet = Unet3d(in_fea_num, out_fea_num)
        return unet
    
    elif unet_name=="adjust_unet":
        from adjust_unet3d import UNet3d
        unet =UNet3d(in_channels = in_fea_num, basic_channels=16, out_channels=out_fea_num, input_shape=grid, layer_depth=4)
        return unet
    
    elif unet_name=="att_unet_fft":
        from att_unet3d_fft import AttUNet3d
        unet = AttUNet3d(in_channels=in_fea_num, basic_channels=16, out_channels=out_fea_num, input_shape=grid, layer_depth=4)
        return unet
    
    elif unet_name=="att_unet_fft_light":
        from att_unet3d_fft_light import AttUNet3d
        unet = AttUNet3d(in_channels=in_fea_num, basic_channels=16, out_channels=out_fea_num, input_shape=grid, layer_depth=4)
        return unet
    
    elif unet_name=="att_unet_fft_none":
        from att_unet3d_fft_none import AttUNet3d
        unet = AttUNet3d(in_channels=in_fea_num, basic_channels=16, out_channels=out_fea_num, input_shape=grid, layer_depth=4)
        return unet

def imnet_select(imnet_name="meshfree_imnet", in_fea_num=32, out_fea_num=4, activation=nn.Softplus):
    if imnet_name=="meshfree_imnet":
        sys.path.append(os.path.join(current_dir, "..", "meshfreeflownet", "src"))
        from implicit_net import ImNet
        imnet = ImNet(dim=3, in_features=in_fea_num, nf=32, 
                  activation=activation, 
                  out_features=out_fea_num)
        return imnet
    
    elif imnet_name=="gan_imnet":
        sys.path.append(os.path.join(current_dir, "..", "gan"))
        from gan_imnet import ImNet
        imnet = ImNet(dim=3, in_features=in_fea_num, out_features=out_fea_num)
        return imnet
    
    elif imnet_name=="adjust_imnet":
        from adjust_imnet import ImNet
        imnet = ImNet(dim=3, in_features=in_fea_num, out_features=out_fea_num, n_base_feature=32)
        return imnet
    
    elif imnet_name=="att_imnet3":
        from res_imnet import ImNet
        imnet = ImNet(dim=3, in_features=in_fea_num, out_features=out_fea_num, n_base_feature=32)
        return imnet
    
def discriminater_select(discriminater_name="att_discriminater", phy_fea_num=4):
    if discriminater_name=="att_discriminater":
        sys.path.append(os.path.join(current_dir, "..", "gan"))
        from discriminater import Discriminator
        discriminater = Discriminator(input_size=(3+phy_fea_num), neck_size=(3+phy_fea_num)*2, output_size=(3+phy_fea_num))
        return discriminater

