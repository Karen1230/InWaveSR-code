from abc import ABC, abstractmethod
import sys
import os
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import cv2
from scipy.signal import convolve2d

import data_flie_transform as dft
import npdata_visualize as nvl

class GridProcess(dft.DataToData):
    @abstractmethod
    def __call__(self):
        pass

class NpdataZXAddDimT(GridProcess):
    def __call__(self, npdata_zx, nt):
        dtype = npdata_zx.dtype
        npdata_list = []
        for _ in range(nt):
            npdata_list.append(npdata_zx[:])
        npdata_tzx = np.stack(npdata_list, 0)
        npdata_tzx = npdata_tzx.astype(dtype)
        return npdata_tzx

class FeaToAreaFea(GridProcess):
    def __call__(self, npdata_fea, npdata_area_zx):
        dtype = npdata_fea.dtype
        grid_process_fun = NpdataZXAddDimT()
        npdata_area_tzx = grid_process_fun(npdata_area_zx, npdata_fea.shape[0])
        npdata_area_fea = npdata_area_tzx * npdata_fea
        max_value = np.max(npdata_area_fea)
        if max_value > 0:
            npdata_area_fea[npdata_area_fea==0.0] = max_value
            min_value = np.min(npdata_area_fea)
        else:
            min_value = np.min(npdata_area_fea)
            npdata_area_fea[npdata_area_fea==0.0] = min_value
            max_value = np.max(npdata_area_fea)
            
        npdata_area_fea[npdata_area_tzx==0.0] = (min_value + max_value) / 2
        npdata_area_fea = npdata_area_fea.astype(dtype)
        return npdata_area_fea
    
class AdjustObsValueByArea(GridProcess):
    def __call__(self, npdata_fea, npdata_area_zx, npdata_sod_zx, adjust_alpha=0.5):
        dtype = npdata_fea.dtype
        grid_process_fun = NpdataZXAddDimT()
        npdata_sod_tzx = grid_process_fun(npdata_sod_zx, npdata_fea.shape[0])
        grid_process_fun = FeaToAreaFea()
        npdata_area_fea_zx = grid_process_fun(npdata_fea, npdata_area_zx)
        min_value = np.min(npdata_area_fea_zx)
        max_value = np.max(npdata_area_fea_zx)
        npdata_adjust_fea = npdata_fea[:]
        adjust_value = min_value + (max_value - min_value) * adjust_alpha
        npdata_adjust_fea[npdata_sod_tzx==0] = adjust_value
        npdata_adjust_fea = npdata_adjust_fea.astype(dtype)
        return npdata_adjust_fea

# get eage image by sea obcstance distribution image
class SodToSoEage(GridProcess):
    def __call__(self, npdata_sod):
        dtype = npdata_sod.dtype
        npdata_sbd_uint8 = (npdata_sod[:] * 255).astype(np.uint8)
        npdata_sbd_uint8_3d = np.stack([npdata_sbd_uint8] * 3, axis=-1)
        npdata_edge_uint8 = cv2.Canny(npdata_sbd_uint8_3d, 100, 200)
        npdata_edge = np.array(npdata_edge_uint8).astype(dtype) / 255
        return npdata_edge
    
class SoEageExpand(GridProcess):
    def __call__(self, npdata_soeage, expand_alpha):
        dtype = npdata_soeage.dtype
        npdata_expan_soeage = npdata_soeage[:]
        kernel = np.array([[0, 1, 0], [1, 0, 1], [0, 1, 0]])
        for _ in range(expand_alpha):
            npdata_expan_soeage = convolve2d(npdata_expan_soeage, kernel, mode="same")
            npdata_expan_soeage[npdata_expan_soeage!=0.0] = 1.0
        npdata_expan_soeage = npdata_expan_soeage.astype(dtype)
        return npdata_expan_soeage

class ExpanSoEageToOutExpanSoEage(GridProcess):
    def __call__(self, npdata_expan_soeage, npdata_sod):
        dtype = npdata_expan_soeage.dtype
        npdata_outexpan_soeage = npdata_expan_soeage[:]
        npdata_outexpan_soeage[npdata_sod==0.0] = 0.0
        npdata_outexpan_soeage = npdata_outexpan_soeage.astype(dtype)
        return npdata_outexpan_soeage

def main():
    figsize = (24, 10)
    fontsize = 20
    data_file_folder = "data"
    data_file_name = "eval.npz"
    dtype = "float32"
    image_folder = os.path.join("src", "grid_process_test_image")
    sod_name = "sbd"
    fea_names = ["rho", "b", "u", "w"]
    soeage_name = "soeage"
    expan_soeage_name = "expan_soeage"
    outexpan_soeage_name = "outexpan_soeage"
    t_id = 256
    colorbar_orientation = "horizontal"
    expand_alpha = 15
    fea_adjust_alphas = [-0.1, -0.1, 0.1, 0.1]

    draw_fun = nvl.DrawHeatImage(colorbar_orientation=colorbar_orientation)
    image_generator = nvl.SingleImageGenerator(figsize=figsize, fontsize=fontsize, draw_fun=draw_fun)

    npdata_dict = np.load(os.path.join(data_file_folder, data_file_name))
    npdata_sod = npdata_dict[sod_name].astype(dtype)
    image_generator(npdata_sod, image_folder, sod_name, sod_name)

    grid_process_fun = SodToSoEage()
    npdata_soeage = grid_process_fun(npdata_sod)
    image_generator(npdata_soeage, image_folder, soeage_name, soeage_name)

    grid_process_fun = SoEageExpand()
    npdata_expan_soeage = grid_process_fun(npdata_soeage, expand_alpha=expand_alpha)
    image_generator(npdata_expan_soeage, image_folder, expan_soeage_name, expan_soeage_name)

    grid_process_fun = ExpanSoEageToOutExpanSoEage()
    npdata_outexpan_soeage = grid_process_fun(npdata_expan_soeage, npdata_sod)
    image_generator(npdata_outexpan_soeage, image_folder, outexpan_soeage_name, outexpan_soeage_name)

    for fea_id, fea_name in enumerate(fea_names):
        npdata_fea = npdata_dict[fea_name].astype(dtype)
        image_generator(npdata_fea[t_id], image_folder, fea_name, fea_name)

        grid_process_fun = FeaToAreaFea()
        npdata_area_fea = grid_process_fun(npdata_fea, npdata_outexpan_soeage)
        image_generator(npdata_area_fea[t_id], image_folder, f"area_{fea_name}", f"area_{fea_name}")

        grid_process_fun = AdjustObsValueByArea()
        npdata_adjust_fea = grid_process_fun(npdata_fea, npdata_outexpan_soeage, npdata_sod, adjust_alpha=fea_adjust_alphas[fea_id])
        image_generator(npdata_adjust_fea[t_id], image_folder, f"adjust_{fea_name}", f"adjust_{fea_name}")

if __name__ == "__main__":
    main()
