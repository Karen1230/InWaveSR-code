import torch
import torch.nn as nn

class ResBlock3D(nn.Module):
    def __init__(self, in_channels, neck_channels, out_channels, final_relu=True):
        super(ResBlock3D, self).__init__()

        self.conv1 = nn.Conv3d(in_channels  , neck_channels, kernel_size=1, stride=1, padding=0)
        self.conv2 = nn.Conv3d(neck_channels, neck_channels, kernel_size=3, stride=1, padding=1)
        self.conv3 = nn.Conv3d(neck_channels, out_channels , kernel_size=1, stride=1, padding=0)

        self.bn1 = nn.BatchNorm3d(num_features=neck_channels)
        self.bn2 = nn.BatchNorm3d(num_features=neck_channels)
        self.bn3 = nn.BatchNorm3d(num_features=out_channels )

        self.relu1 = nn.ReLU()
        self.relu2 = nn.ReLU()
        self.relu3 = nn.ReLU()

        self.shortcut = nn.Conv3d(in_channels, out_channels, kernel_size=1, stride=1)
        self.final_relu = final_relu

    def forward(self, x):
        identity = x

        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu1(x)

        x = self.conv2(x)
        x = self.bn2(x)
        x = self.relu2(x)

        x = self.conv3(x)
        x = self.bn3(x)

        x += self.shortcut(identity)
        if self.final_relu:
            x = self.relu3(x)

        return x

class UNet3d(nn.Module):

    def __init__(self, in_channels, basic_channels, out_channels, input_shape, layer_depth):
        super(UNet3d, self).__init__()
        self.layer_depth = layer_depth

        channel_list = self.create_channel_seq(basic_channels)
        multiple_list = self.create_multiple_seq(input_shape)

        self.input_layer = nn.Sequential(
            ResBlock3D(in_channels, basic_channels, basic_channels)
        )

        down_layers = []
        for i in range(layer_depth):
            down_layers.append(
                nn.Sequential(
                    ResBlock3D(channel_list[i], channel_list[i], channel_list[i+1]), 
                    nn.MaxPool3d(multiple_list[i]),
            ))
        self.down_layers = nn.ModuleList(down_layers)

        up_layers = []
        up_layers.append(
            nn.Sequential(
                ResBlock3D(channel_list[layer_depth], channel_list[layer_depth-1], channel_list[layer_depth-1]), 
                nn.Upsample(scale_factor=tuple(multiple_list[layer_depth-1])),
        ))
        for i in range(1, layer_depth):
            up_layers.append(
                nn.Sequential(
                    ResBlock3D(channel_list[layer_depth-i] * 2, channel_list[layer_depth-i-1], channel_list[layer_depth-i-1]), 
                    nn.Upsample(scale_factor=tuple(multiple_list[layer_depth-i-1])),
            ))
        self.up_layers = nn.ModuleList(up_layers)

        self.output_layer = nn.Sequential(
            ResBlock3D(basic_channels*2, out_channels, out_channels, final_relu=False)
        )

    def forward(self, x, lres_sod=None):

        x = self.input_layer(x) # (16, 4, 16, 16)

        x_list = [x]
        for down_layer in self.down_layers:
            x = x_list[-1]
            x = down_layer(x)
            x_list.append(x)

        x = x_list.pop()
        for up_layer in self.up_layers:
            x = up_layer(x)
            x = torch.cat([x, x_list.pop()], dim=1) # (256, 2, 2, 2)

        x = self.output_layer(x) # (32, 4, 16, 16)

        return x
    
    def create_channel_seq(self, basic_channels):
        channel_list = []
        for i in range(self.layer_depth+1):
            channel_list.append(basic_channels * 2 ** i)
        return channel_list
    
    def create_multiple_seq(self, input_shape):
        multiple_list = []
        for i in range(self.layer_depth):
            shape_list = []
            for dim_id in range(3):
                if input_shape[dim_id] < 2 ** (self.layer_depth - i):
                    shape_list.append(1)
                else:
                    shape_list.append(2)
            multiple_list.append(shape_list)
        return multiple_list


def main():
    input_shape=[4, 16, 8]
    model = UNet3d(in_channels=4, basic_channels=16, out_channels=32, input_shape=input_shape, layer_depth=4)
    input = torch.rand(10, 4, input_shape[0], input_shape[1], input_shape[2])
    output = model(input)
    print( sum(x.numel() for x in model.parameters()))
    print(f"output's shape: {output.shape}")


if __name__ == '__main__':
    main()

