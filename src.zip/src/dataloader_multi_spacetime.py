"""RB2 Experiment Dataloader"""
import os
import torch
from torch.utils.data import Dataset, Sampler
import numpy as np
from scipy.interpolate import RegularGridInterpolator
from scipy import ndimage
import warnings
# pylint: disable=too-manz-arguments, too-manz-instance-attributes, too-manz-locals
import sys
# sys.path.append("meshfreeflownet")
import dataloader_spacetime

import point_samp3d

current_dir = os.path.dirname(os.path.realpath(__file__))
sys.path.append(os.path.join("..", "src"))
import npdata_visualize as nvl


class RB2MultiDataLoader(dataloader_spacetime.RB2DataLoader):
    def __init__(self, data_dir="./", data_filenames=["./data/rb2d_ra1e6_s42.npz"],
                 nx=128, nz=128, nt=16, n_samp_pts_per_crop=1024,
                 downsamp_x=4, downsamp_z=4, downsamp_t=4, normalize_output=False, normalize_hres=False,
                 return_hres=False, lres_filter='none', lres_interp='linear', use_visual=False, 
                 phy_fea_names=["p", "b", "u", "w"], swap_zx=False, log_folder=".", with_dis_file=False, terrain_zero=False):
        
        self.data_filenames = data_filenames

        super(RB2MultiDataLoader, self).__init__(
                 data_dir=data_dir, data_filename=None,
                 nx=nx, nz=nz, nt=nt, n_samp_pts_per_crop=n_samp_pts_per_crop,
                 downsamp_x=downsamp_x, downsamp_z=downsamp_z, downsamp_t=downsamp_t, 
                 normalize_output=normalize_output, normalize_hres=normalize_hres,
                 return_hres=return_hres, lres_filter=lres_filter, lres_interp=lres_interp, use_visual=use_visual,
                 phy_fea_names=phy_fea_names, swap_zx=swap_zx, log_folder=log_folder,
                 with_dis_file=with_dis_file, terrain_zero=terrain_zero)
    
    # visual init
    def _set_visual(self, use_visual, log_folder):
        if use_visual:
            figsize = (24, 10)
            fontsize = 20
            colorbar_orientation = "horizontal"
            draw_fun = point_samp3d.DrawHeatImage(colorbar_orientation=colorbar_orientation)
            self.image_generator = point_samp3d.SingleImageGeneratorUnlimit(figsize=figsize, fontsize=fontsize, draw_fun=draw_fun)
            self.image_folder = os.path.join(log_folder, "seaobs_dataset_test_image")
            self.use_visual_init = True
            self.use_visual_getitem = True
            self.visual_data_t_id = 128
            self.visual_data_d_id = 0
            self.visual_hres_crop_t_id = 10
            self.use_visual_getitem_id = 0
        else:
            self.use_visual_init = False
            self.use_visual_getitem = False

    # the num of visual should be limited
    def _adjust_visual(self):
        if self.use_visual_getitem and self.use_visual_getitem_id >= 10:
            self.use_visual_getitem = False

    # get spatial density of points by space_time_crop_hres(stch) grid
    def _get_point_diss(self, point_coord, stch_grid):

        if self.with_dis_file:
            coord0 = np.floor(point_coord).astype(np.int64)
            dis_list = []
            for i in range(len(coord0)):
                t, z, x = coord0[i]
                dis = stch_grid[t+1, z+1, x+1] - stch_grid[t, z, x]
                dis_list.append(dis)

            diss = np.abs(np.stack(dis_list, axis=0))
            point_diss = diss.astype(np.float32)
        else:
            point_diss = None

        return point_diss
        
    # get data and shape by file and feature name list
    def _get_data_and_dim(self, phy_fea_names):        
        multi_data_list = []
        for data_filename in self.data_filenames:
            npdata_dict = np.load(os.path.join(self.data_dir, data_filename))
            data, _ = self._get_data_and_dim_by_npdata_dict(npdata_dict, phy_fea_names)
            multi_data_list.append(data)
        multi_data = np.stack(multi_data_list, axis=0)
        self.dataset_num, nc_data, nt_data, nz_data, nx_data = multi_data.shape
        return multi_data, (nc_data, nt_data, nz_data, nx_data)
    
    # get grid data 
    def _get_gird(self):
        multi_npdata_grid_list = []
        for data_filename in self.data_filenames:
            npdata = np.load(os.path.join(self.data_dir, data_filename))
            data_grid = npdata["grid"]
            multi_npdata_grid_list.append(data_grid)
        multi_data_grid = np.stack(multi_npdata_grid_list, axis=0)

        self.data_grid = multi_data_grid
    
    # get mean and std of multi data
    def _get_mean_std(self):
        mean = np.mean(self.data.astype(np.float64), axis=(0, 2, 3, 4)).astype(np.float32)
        std = np.std(self.data.astype(np.float64), axis=(0, 2, 3, 4)).astype(np.float32)
        return mean, std
    
    # get file id and dim id by id
    def _get_dim_id(self, idx):
        rand_start_id_id = int(idx // self.dataset_num)
        dataset_id = int(idx % self.dataset_num)
        t_id, z_id, x_id = self.rand_start_id[rand_start_id_id]
        return dataset_id, t_id, z_id, x_id
    
    # get crop by id
    def _get_space_time_crop_hres(self, idx):
        dataset_id, t_id, z_id, x_id = self._get_dim_id(idx)
        space_time_crop_hres = self.data[dataset_id,
                                         :,
                                         t_id:t_id+self.nt_hres,
                                         z_id:z_id+self.nz_hres,
                                         x_id:x_id+self.nx_hres]  # [d, c, t, z, x]
        return space_time_crop_hres
    
    # # get grid crop by id
    def _get_space_time_crop_hres_grid(self, idx):
        if self.with_dis_file:
            dataset_id, t_id, z_id, x_id = self._get_dim_id(idx)
            space_time_crop_hres_grid = self.data_grid[dataset_id,
                                            t_id:t_id+self.nt_hres,
                                            z_id:z_id+self.nz_hres,
                                            x_id:x_id+self.nx_hres]  # [d, t, z, x]
            return space_time_crop_hres_grid
        else:
            return None

