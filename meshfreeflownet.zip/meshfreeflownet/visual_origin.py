import os
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import argparse
import json
import sys

def frames_to_video(frames_pattern, save_video_to, frame_rate=10):
    """Create video from frames.

    frames_pattern: str, glob pattern of frames.
    save_video_to: str, path to save video to.
    keep_frames: bool, whether to keep frames after generating video.
    """
    cmd = ("/home/hanpeng/anaconda3/envs/linuxconda/bin/ffmpeg" 
           " -framerate {frame_rate} -pattern_type glob -i '{frames_pattern}' "
           "-c:v libx264 -r 30 -pix_fmt yuv420p {save_video_to}"
           .format(frame_rate=frame_rate, frames_pattern=frames_pattern,
                   save_video_to=save_video_to))
    os.system(cmd)
    # print
    print("Saving videos to {}".format(save_video_to))
    # # delete frames if keep_frames is not needed
    # if not keep_frames:
    #     frames_dir = os.path.dirname(frames_pattern)
    #     shutil.rmtree(frames_dir)

def visual(args, npdata_dict):
    phys_channels = args.phy_fea_names
    lres = npdata_dict["lres"]
    hres = npdata_dict["hres"]
    pred = npdata_dict["pred"]

    for idx, name in enumerate(phys_channels):
        frames_dir = os.path.join(args.eval_folder, f'frames_{name}')
        os.makedirs(frames_dir, exist_ok=True)
        hres_frames = hres[idx]
        lres_frames = lres[idx]
        pred_frames = pred[idx]

        # loop over each timestep in pred_frames
        max_val = np.max(hres_frames)
        min_val = np.min(hres_frames)

        for pid in range(pred_frames.shape[0]):
            hid = int(np.round(pid / (pred_frames.shape[0] - 1) * (hres_frames.shape[0] - 1)))
            lid = int(np.round(pid / (pred_frames.shape[0] - 1) * (lres_frames.shape[0] - 1)))

            fig, axes = plt.subplots(3, figsize=(10, 10))#, 1, sharex=True)
            # high res ground truth
            im0 = axes[0].imshow(hres_frames[hid], cmap='RdBu',interpolation='spline16')
            axes[0].set_title(f'{name} channel, high res ground truth.')
            im0.set_clim(min_val, max_val)
            # low res input
            im1 = axes[1].imshow(lres_frames[lid], cmap='RdBu',interpolation='none', aspect=int(args.eval_downsamp_z/args.eval_downsamp_x))
            axes[1].set_title(f'{name} channel, low  res ground truth.')
            im1.set_clim(min_val, max_val)
            # prediction
            im2 = axes[2].imshow(pred_frames[pid], cmap='RdBu',interpolation='spline16')
            axes[2].set_title(f'{name} channel, predicted values.')
            im2.set_clim(min_val, max_val)
            # add shared colorbar
            cbaxes = fig.add_axes([0.1, 0, .82, 0.05])
            fig.colorbar(im2, orientation="horizontal", pad=0, cax=cbaxes)
            frame_name = 'frame_{:03d}.png'.format(pid)
            fig.savefig(os.path.join(frames_dir, frame_name))

            plt.close()

        # stitch frames into video (using ffmpeg)
        frames_to_video(
            frames_pattern=os.path.join(frames_dir, "*.png"),
            save_video_to=os.path.join(args.eval_folder, f"video_{name}.mp4"),
            frame_rate=args.frame_rate)