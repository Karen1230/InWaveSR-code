#!/bin/bash

mkdir -p data
wget island.me.berkeley.edu/stsres/rb2d_ra1e6_s42.npz && mv rb2d_ra1e6_s42.npz data 
