import sys
sys.path.append("../../src")
from pde import PDELayer

# revised: In the comment below, replace the number 4 with phy_fea_num.

defualt_eqn_strs = [
    '{nt}*dif(b,t)-{P}*(({nx})**2*dif(dif(b,x),x)+({nz})**2*dif(dif(b,z),z))             +(u*{nx}*dif(b,x)+w*{nz}*dif(b,z))',
    # b 换成 s, 字母P随便换个名字
    '{nt}*dif(b,t)-{P}*(({nx})**2*dif(dif(b,x),x)+({nz})**2*dif(dif(b,z),z))             +(u*{nx}*dif(b,x)+w*{nz}*dif(b,z))',
    # '{nt}*dif(u,t)-{R}*(({nx})**2*dif(dif(u,x),x)+({nz})**2*dif(dif(u,z),z))+dif(p,x)    +(u*{nx}*dif(u,x)+w*{nz}*dif(u,z))',
    # '{nt}*dif(w,t)-{R}*(({nx})**2*dif(dif(w,x),x)+({nz})**2*dif(dif(w,z),z))+dif(p,z)-b  +(u*{nx}*dif(w,x)+w*{nz}*dif(w,z))',
    '{nx} * dif(u, x) + {nz} * dif(w, z)',
]

defualt_eqn_names = ['transport_eqn_b', 'transport_eqn_u', 'transport_eqn_w', 'continuity']

def get_rb2_pde_layer(mean=None, std=None, t_crop=2., z_crop=1., x_crop=2., prandtl=1., rayleigh=1e6, use_continuity=False, 
                      out_vars = 'p, b, u, w', eqn_names=defualt_eqn_names, eqn_strs=defualt_eqn_strs, 
                      hres_nt=16, hres_nz=128, hres_nx=128, dist_t=600, dist_z=10, dist_x=200, 
                      with_dis_file=False):
    """Get PDE layer corresponding to the RB2 govening equations.

    Args:
        mean: array of length 4 corresponding to the mean of the 4 physical channels, for normalizng
        the equations. does not normalize if set to None (default).
        std: array of length 4 corresponding to the std of the 4 physical channels, for normalizing
        the equations. does not normalize if set to None (default).
        t_crop: float, physical temporal span of crop.
        z_crop: float, physical z-width of crop.
        x_crop: float, physical x-width of crop.
    """
    # constants
    P = (rayleigh * prandtl)**(-1/2)
    R = (rayleigh / prandtl)**(-1/2)
    # set up variables and equations
    in_vars = 't, x, z'
    # out_vars = 'p, b, u, w'
    phy_fea_names = out_vars.replace(" ", "").split(",")
    phy_fea_num = len(phy_fea_names)
    
    if not with_dis_file:

        nt = 1. / ((hres_nt-1) * dist_t )
        nz = 1. / ((hres_nz-1) * dist_z )
        nx = 1. / ((hres_nx-1) * dist_x ) if not hres_nx == 1 else 0

        replace_dict = {
            "{nx}": nx, "{nz}": nz, "{nt}": nt, 
            "{P}": P, "{R}": R,
        }

    else: 
        replace_dict = {
            "{nx}": "DT", "{nz}": "DZ", "{nt}": "DX", 
            "{P}": P, "{R}": R,
        }

    for eqn_id, eqn_str in enumerate(eqn_strs):
        for replace_key, replace_value in replace_dict.items():
            eqn_strs[eqn_id] = eqn_strs[eqn_id].replace(replace_key, str(replace_value))

    # eqn_strs = [
    #     f'{nt}*dif(b,t)-{P}*(({nx})**2*dif(dif(b,x),x)+({nz})**2*dif(dif(b,z),z))             +(u*{nx}*dif(b,x)+w*{nz}*dif(b,z))',
    #     f'{nt}*dif(u,t)-{R}*(({nx})**2*dif(dif(u,x),x)+({nz})**2*dif(dif(u,z),z))+dif(p,x)    +(u*{nx}*dif(u,x)+w*{nz}*dif(u,z))',
    #     f'{nt}*dif(w,t)-{R}*(({nx})**2*dif(dif(w,x),x)+({nz})**2*dif(dif(w,z),z))+dif(p,z)-b  +(u*{nx}*dif(w,x)+w*{nz}*dif(w,z))',
    # ]
    # # a name/identifier for the equations
    # eqn_names = ['transport_eqn_b', 'transport_eqn_u', 'transport_eqn_w']

    # if use_continuity:
    #     eqn_strs.append(f'{nx} * dif(u, x) + {nz} * dif(w, z)')
    #     eqn_names.append('continuity')

    # normalize equations (optional) via change of variables.
    if (mean is not None) or (std is not None):
        # check the validity of mean and std
        if not ((mean is not None) and (std is not None)):
            raise ValueError('mean and std must either be both None, or both arrays of len 4.')
        if not (hasattr(mean, '__len__') and hasattr(mean, '__len__')):
            raise TypeError(("mean and std must be arrays of len 4. instead they are {} and {}"
                             .format(type(mean), type(std))))
        if not (len(mean) == phy_fea_num and len(std) == phy_fea_num):
            raise ValueError(
                ("mean and std must be arrays of len 4. instead they are of len {} and {}"
                 .format(len(mean), len(std))))
        # substitute variables
        subs_dict = {}
        out_vars_list = [v.strip() for v in out_vars.split(',')]
        for idx, var in enumerate(out_vars_list):
            var_subs = f"{var}*{std[idx]}+{mean[idx]}"
            subs_dict[var] = var_subs
    else:
        subs_dict = None

    # initialize the pde layer
    if not with_dis_file:
        pde_layer = PDELayer(in_vars=in_vars, out_vars=out_vars)
    else:
        dis_vars = "DT, DZ, DX"
        pde_layer = PDELayer(in_vars=in_vars, out_vars=out_vars, dis_vars=dis_vars, hres_shape = (hres_nt, hres_nz, hres_nx))

    for eqn_str, eqn_name in zip(eqn_strs, eqn_names):  # add equations
        pde_layer.add_equation(eqn_str, eqn_name, subs_dict=subs_dict)

    return pde_layer  # NOTE: forward method has not yet been updated.